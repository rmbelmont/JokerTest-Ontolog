package br.unirio.jokertest;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;

import com.itextpdf.kernel.colors.Color;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Text;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * JokerTestPDFGenerator - Gerador de PDF para JokerTest-Ontology
 *
 * Teste Psicológico do Coringa em "The Dark Knight" (2008)
 *
 * Questões de Competência:
 * Q1: Embarcações participantes
 * Q2: Passageiros por embarcação
 * Q3: Detentores dos detonadores
 * Q4: Resultado do teste
 * Q5: Sobreviventes
 * Q6: Mortos
 * Q7: Hipótese do Coringa confirmada?
 */
public class JokerTestPDFGenerator {

    private static final String NS = "http://www.unirio.br/jokertest/ontology#";

    // ============================================================
    // CAMINHO CORRIGIDO
    // ============================================================
    private static final String DEFAULT_ONTOLOGY_PATH =
        "D:/EclipseLunar/workspace/TestePsicologicoBatman_2/ontology/jokertest-ontology.rdf";

    // Cores temáticas (Joker - roxo, verde, vermelho)
    private static final Color JT_PURPLE = new DeviceRgb(75, 0, 130);
    private static final Color JT_LIGHT_PURPLE = new DeviceRgb(240, 230, 250);
    private static final Color JT_DARK_GRAY = new DeviceRgb(60, 60, 60);
    private static final Color JT_GREEN = new DeviceRgb(0, 130, 60);
    private static final Color JT_CRIMSON = new DeviceRgb(180, 10, 40);
    private static final Color JT_DARK_RED = new DeviceRgb(120, 0, 0);
    private static final Color JT_TEAL = new DeviceRgb(0, 110, 110);
    private static final Color JT_GOLD = new DeviceRgb(190, 150, 0);
    private static final Color JT_BROWN = new DeviceRgb(120, 60, 20);
    private static final Color JT_NAVY = new DeviceRgb(20, 40, 90);

    private OWLOntologyManager manager;
    private OWLOntology ontology;
    private OWLDataFactory factory;
    private OWLReasoner reasoner;

    // Propriedades de Objeto
    private OWLObjectProperty propTemOcupacao;
    private OWLObjectProperty propTemDetonador;
    private OWLObjectProperty propControlaEmbarcacao;
    private OWLObjectProperty propEstaEm;
    private OWLObjectProperty propAciona;
    private OWLObjectProperty propObserva;
    private OWLObjectProperty propTemPrazo;
    private OWLObjectProperty propTestaHipotese;
    private OWLObjectProperty propSobreviveu;
    private OWLObjectProperty propMorreu;
    private OWLObjectProperty propImpedeExplosao;

    // Propriedades de Dados
    private OWLDataProperty dphHasName;
    private OWLDataProperty dphHasDescription;
    private OWLDataProperty dphFoiImpedidaExplosao;
    private OWLDataProperty dphDetonadorAcionado;
    private OWLDataProperty dphHipoteseConfirmada;
    private OWLDataProperty dphHasScoreMoral;
    private OWLDataProperty dphHasSource;

    public JokerTestPDFGenerator() throws Exception {
        this(loadOntology());
    }

    public JokerTestPDFGenerator(OWLOntology ontology) {
        try {
            this.ontology = ontology;
            this.manager = ontology.getOWLOntologyManager();
            this.factory = manager.getOWLDataFactory();

            StructuralReasonerFactory reasonerFactory = new StructuralReasonerFactory();
            this.reasoner = reasonerFactory.createReasoner(ontology);

            initializeProperties();

            System.out.println("✅ Ontologia carregada para PDF");
            System.out.println("   Axiomas: " + ontology.getAxiomCount());
            System.out.println("   Classes: " + ontology.getClassesInSignature().size());
            System.out.println("   Indivíduos: " + ontology.getIndividualsInSignature().size());

        } catch (Exception e) {
            System.err.println("❌ Erro ao carregar ontologia para PDF: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static OWLOntology loadOntology() throws Exception {
        OWLOntologyManager mgr = OWLManager.createOWLOntologyManager();
        File ontologyFile = new File(DEFAULT_ONTOLOGY_PATH);
        if (!ontologyFile.exists()) {
            throw new Exception("Arquivo de ontologia não encontrado: " + ontologyFile.getAbsolutePath());
        }
        System.out.println("📄 Carregando ontologia de: " + ontologyFile.getAbsolutePath());
        return mgr.loadOntologyFromOntologyDocument(ontologyFile);
    }

    private void initializeProperties() {
        propTemOcupacao = getObjectProperty("temOcupacao");
        propTemDetonador = getObjectProperty("temDetonador");
        propControlaEmbarcacao = getObjectProperty("controlaEmbarcacao");
        propEstaEm = getObjectProperty("estaEm");
        propAciona = getObjectProperty("aciona");
        propObserva = getObjectProperty("observa");
        propTemPrazo = getObjectProperty("temPrazo");
        propTestaHipotese = getObjectProperty("testaHipotese");
        propSobreviveu = getObjectProperty("sobreviveu");
        propMorreu = getObjectProperty("morreu");
        propImpedeExplosao = getObjectProperty("impedeExplosao");

        dphHasName = getDataProperty("hasName");
        dphHasDescription = getDataProperty("hasDescription");
        dphFoiImpedidaExplosao = getDataProperty("foiImpedidaExplosao");
        dphDetonadorAcionado = getDataProperty("detonadorAcionado");
        dphHipoteseConfirmada = getDataProperty("hipoteseConfirmada");
        dphHasScoreMoral = getDataProperty("hasScoreMoral");
        dphHasSource = getDataProperty("hasSource");
    }

    private OWLObjectProperty getObjectProperty(String name) {
        return factory.getOWLObjectProperty(IRI.create(NS + name));
    }

    private OWLDataProperty getDataProperty(String name) {
        return factory.getOWLDataProperty(IRI.create(NS + name));
    }

    // ============================================================
    // MÉTODOS DE CONSULTA
    // ============================================================

    private Set<OWLNamedIndividual> getIndividualsByPrefix(String prefix) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (ontology == null) return result;

        try {
            Set<OWLNamedIndividual> allInds = ontology.getIndividualsInSignature();
            for (OWLNamedIndividual ind : allInds) {
                String iri = ind.getIRI().getShortForm();
                if (iri.startsWith(prefix)) {
                    result.add(ind);
                }
            }
        } catch (Exception e) { /* ignore */ }
        return result;
    }

    private Set<OWLNamedIndividual> getFerries() {
        return getIndividualsByPrefix("Embarcacao_");
    }

    private Set<OWLNamedIndividual> getPassengers() {
        Set<OWLNamedIndividual> result = new HashSet<>();
        result.addAll(getIndividualsByPrefix("Civil"));
        result.addAll(getIndividualsByPrefix("Prisioneiro"));
        result.addAll(getIndividualsByPrefix("Policial"));
        result.addAll(getIndividualsByPrefix("Guarda"));
        return result;
    }

    private Set<OWLNamedIndividual> getDetonators() {
        return getIndividualsByPrefix("Detonador_");
    }

    private Set<OWLNamedIndividual> getBombs() {
        return getIndividualsByPrefix("Bomba_");
    }

    private String getDataValue(OWLNamedIndividual individual, OWLDataProperty prop) {
        if (individual == null || prop == null) return null;
        try {
            Set<OWLDataPropertyAssertionAxiom> axioms = ontology.getDataPropertyAssertionAxioms(individual);
            for (OWLDataPropertyAssertionAxiom axiom : axioms) {
                if (axiom.getProperty().equals(prop)) {
                    OWLLiteral literal = (OWLLiteral) axiom.getObject();
                    return literal.getLiteral();
                }
            }
        } catch (Exception e) { /* ignore */ }
        return null;
    }

    private String getName(OWLNamedIndividual individual) {
        if (individual == null) return "N/A";
        String name = getDataValue(individual, dphHasName);
        if (name != null && !name.isEmpty()) return name;
        String iri = individual.getIRI().getShortForm();
        return iri.replace("_", " ");
    }

    private Set<OWLNamedIndividual> getRelated(OWLNamedIndividual individual, OWLObjectProperty prop) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (individual == null || prop == null || ontology == null) return result;

        try {
            Set<OWLObjectPropertyAssertionAxiom> axioms = ontology.getObjectPropertyAssertionAxioms(individual);
            for (OWLObjectPropertyAssertionAxiom axiom : axioms) {
                if (axiom.getProperty().equals(prop) && axiom.getSubject().equals(individual)) {
                    OWLIndividual object = axiom.getObject();
                    if (object instanceof OWLNamedIndividual) {
                        result.add((OWLNamedIndividual) object);
                    }
                }
            }
        } catch (Exception e) { /* ignore */ }

        return result;
    }

    private Set<OWLNamedIndividual> getRelatedInverse(OWLNamedIndividual object, OWLObjectProperty prop) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (object == null || prop == null || ontology == null) return result;

        try {
            for (OWLObjectPropertyAssertionAxiom axiom : ontology.getAxioms(AxiomType.OBJECT_PROPERTY_ASSERTION)) {
                if (axiom.getProperty().equals(prop) && axiom.getObject().equals(object)) {
                    OWLIndividual subject = axiom.getSubject();
                    if (subject instanceof OWLNamedIndividual) {
                        result.add((OWLNamedIndividual) subject);
                    }
                }
            }
        } catch (Exception e) { /* ignore */ }

        return result;
    }

    private Set<OWLNamedIndividual> getPassengersOf(OWLNamedIndividual ferry) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        result.addAll(getRelated(ferry, propTemOcupacao));
        result.addAll(getRelatedInverse(ferry, propEstaEm));
        return result;
    }

    private Set<OWLNamedIndividual> getFerryOf(OWLNamedIndividual passenger) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        result.addAll(getRelated(passenger, propEstaEm));
        result.addAll(getRelatedInverse(passenger, propTemOcupacao));
        return result;
    }

    // ============================================================
    // GERAR PDF
    // ============================================================
    public void generatePDF(String outputPath) throws IOException {
        if (ontology == null) {
            throw new IOException("Ontologia não foi carregada.");
        }

        File outputFile = new File(outputPath);
        if (outputFile.getParentFile() != null) {
            outputFile.getParentFile().mkdirs();
        }

        PdfWriter writer = new PdfWriter(outputFile);
        PdfDocument pdfDoc = new PdfDocument(writer);
        pdfDoc.setDefaultPageSize(PageSize.A4);

        Document document = new Document(pdfDoc);
        document.setMargins(40, 40, 40, 40);

        PdfFont fontNormal = PdfFontFactory.createFont("Helvetica");
        PdfFont fontBold = PdfFontFactory.createFont("Helvetica-Bold");
        PdfFont fontItalic = PdfFontFactory.createFont("Helvetica-Oblique");

        // ============================================
        // CABEÇALHO
        // ============================================

        Paragraph title = new Paragraph("JokerTest-Ontology")
                .setFont(fontBold)
                .setFontSize(22)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(JT_PURPLE);
        document.add(title);

        Paragraph subtitle = new Paragraph("Ontologia do Teste Psicológico do Coringa em The Dark Knight (2008)")
                .setFont(fontBold)
                .setFontSize(13)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(JT_DARK_GRAY);
        document.add(subtitle);

        Paragraph subtitle2 = new Paragraph("Dilema Moral, Teoria dos Jogos e Psicologia Social")
                .setFont(fontItalic)
                .setFontSize(10)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(JT_DARK_GRAY);
        document.add(subtitle2);

        Paragraph authors = new Paragraph()
                .setFont(fontNormal)
                .setFontSize(11)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(JT_DARK_GRAY);
        authors.add(new Text("Roberto Monteiro Dias,\n").setFont(fontBold));
        authors.add(new Text("Programa de Pós-Graduação em Informática (PPGI)\n"));
        authors.add(new Text("Universidade Federal do Estado do Rio de Janeiro (UNIRIO)\n"));
        authors.add(new Text("Email: roberto.dias@uniriotec.br"));
        document.add(authors);
        document.add(new Paragraph(" ").setFontSize(4));

        Paragraph separator = new Paragraph("_________________________________________________________________________________")
                .setFont(fontNormal)
                .setFontSize(10)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(JT_DARK_GRAY);
        document.add(separator);

        Paragraph info = new Paragraph()
                .setTextAlignment(TextAlignment.CENTER)
                .setFontSize(9)
                .setFontColor(JT_DARK_GRAY);
        info.add(new Text("Data: ").setFont(fontBold));
        info.add(new Text(java.time.LocalDate.now().toString() + "  ").setFont(fontNormal));
        info.add(new Text("Baseado em: ").setFont(fontBold));
        info.add(new Text("Nolan (2008) - The Dark Knight").setFont(fontItalic));
        document.add(info);
        document.add(new Paragraph(" ").setFontSize(8));

        // ============================================
        // RESUMO
        // ============================================

        Paragraph abstractTitle = new Paragraph("Resumo")
                .setFont(fontBold)
                .setFontSize(11)
                .setTextAlignment(TextAlignment.LEFT)
                .setFontColor(JT_PURPLE);
        document.add(abstractTitle);

        Paragraph abstractText = new Paragraph(
                "Este relatório apresenta a JokerTest-Ontology, uma ontologia de domínio "
                + "para o experimento psicológico conduzido pelo Coringa em The Dark Knight (2008). "
                + "A ontologia formaliza as duas embarcações de evacuação, seus passageiros, "
                + "os detonadores cruzados, a escolha moral binária e as consequências do teste. "
                + "Baseada no Dilema do Prisioneiro da teoria dos jogos e em conceitos da psicologia "
                + "social (difusão de responsabilidade), a ontologia permite responder às 7 questões "
                + "de competência que orientam a análise do experimento, incluindo a refutação "
                + "da hipótese cínica do Coringa sobre a natureza humana."
        ).setFont(fontItalic).setFontSize(9).setTextAlignment(TextAlignment.JUSTIFIED);
        document.add(abstractText);
        document.add(new Paragraph(" ").setFontSize(6));

        // ============================================
        // PALAVRAS-CHAVE
        // ============================================

        Paragraph keywords = new Paragraph()
                .setFont(fontNormal)
                .setFontSize(9)
                .setTextAlignment(TextAlignment.LEFT);
        keywords.add(new Text("Palavras-chave — ").setFont(fontBold));
        keywords.add(new Text("The Dark Knight, Coringa, Dilema do Prisioneiro, Teoria dos Jogos, "
                + "Psicologia Moral, Ontologia, OWL").setFont(fontItalic));
        document.add(keywords);
        document.add(new Paragraph(" ").setFontSize(8));

        document.add(new Paragraph("_________________________________________________________________________________")
                .setFont(fontNormal)
                .setFontSize(10)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(JT_DARK_GRAY));
        document.add(new Paragraph(" ").setFontSize(8));

        // ============================================
        // QUESTÕES DE COMPETÊNCIA
        // ============================================

        Paragraph sectionTitle = new Paragraph("I. QUESTÕES DE COMPETÊNCIA")
                .setFont(fontBold)
                .setFontSize(14)
                .setTextAlignment(TextAlignment.LEFT)
                .setFontColor(JT_PURPLE);
        document.add(sectionTitle);
        document.add(new Paragraph(" ").setFontSize(6));

        // Q1 - Embarcações
        Table q1Table = buildQ1Table(fontNormal, fontBold, fontItalic);
        if (q1Table != null) {
            document.add(q1Table);
            document.add(new Paragraph(" ").setFontSize(4));
        }

        // Q2 - Passageiros
        Table q2Table = buildQ2Table(fontNormal, fontBold, fontItalic);
        if (q2Table != null) {
            document.add(q2Table);
            document.add(new Paragraph(" ").setFontSize(4));
        }

        // Q3 - Detentores
        Table q3Table = buildQ3Table(fontNormal, fontBold, fontItalic);
        if (q3Table != null) {
            document.add(q3Table);
            document.add(new Paragraph(" ").setFontSize(4));
        }

        // Q4 - Resultado
        Table q4Table = buildQ4Table(fontNormal, fontBold, fontItalic);
        if (q4Table != null) {
            document.add(q4Table);
            document.add(new Paragraph(" ").setFontSize(4));
        }

        // Q5 - Sobreviventes
        Table q5Table = buildQ5Table(fontNormal, fontBold, fontItalic);
        if (q5Table != null) {
            document.add(q5Table);
            document.add(new Paragraph(" ").setFontSize(4));
        }

        // Q6 - Mortos
        Table q6Table = buildQ6Table(fontNormal, fontBold, fontItalic);
        if (q6Table != null) {
            document.add(q6Table);
            document.add(new Paragraph(" ").setFontSize(4));
        }

        // Q7 - Hipótese
        Table q7Table = buildQ7Table(fontNormal, fontBold, fontItalic);
        if (q7Table != null) {
            document.add(q7Table);
            document.add(new Paragraph(" ").setFontSize(4));
        }

        // ============================================
        // REFERÊNCIAS
        // ============================================

        document.add(new Paragraph(" ").setFontSize(10));
        document.add(new Paragraph("_________________________________________________________________________________")
                .setFont(fontNormal)
                .setFontSize(10)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(JT_DARK_GRAY));

        Paragraph refTitle = new Paragraph("REFERÊNCIAS")
                .setFont(fontBold)
                .setFontSize(11)
                .setTextAlignment(TextAlignment.LEFT)
                .setFontColor(JT_PURPLE);
        document.add(refTitle);

        Paragraph references = new Paragraph()
                .setTextAlignment(TextAlignment.LEFT)
                .setFontSize(8)
                .setFontColor(JT_DARK_GRAY);

        references.add(new Text("[1] ").setFont(fontBold));
        references.add(new Text("C. Nolan, ")
                .setFont(fontNormal));
        references.add(new Text("The Dark Knight, ")
                .setFont(fontItalic));
        references.add(new Text("Warner Bros. Pictures, 2008.\n").setFont(fontNormal));

        references.add(new Text("[2] ").setFont(fontBold));
        references.add(new Text("A. Rapoport and A. M. Chammah, ")
                .setFont(fontNormal));
        references.add(new Text("Prisoner's Dilemma: A Study in Conflict and Cooperation, ")
                .setFont(fontItalic));
        references.add(new Text("University of Michigan Press, 1965.\n").setFont(fontNormal));

        references.add(new Text("[3] ").setFont(fontBold));
        references.add(new Text("J. M. Darley and B. Latané, ")
                .setFont(fontNormal));
        references.add(new Text("\"Bystander Intervention in Emergencies: Diffusion of Responsibility,\" ")
                .setFont(fontItalic));
        references.add(new Text("Journal of Personality and Social Psychology, vol. 8, no. 4, pp. 377-383, 1968.\n")
                .setFont(fontNormal));

        references.add(new Text("[4] ").setFont(fontBold));
        references.add(new Text("R. Axelrod, ")
                .setFont(fontNormal));
        references.add(new Text("\"More Effective Choice in the Prisoner's Dilemma,\" ")
                .setFont(fontItalic));
        references.add(new Text("Journal of Conflict Resolution, vol. 24, no. 3, pp. 379-403, 1980.\n")
                .setFont(fontNormal));

        references.add(new Text("[5] ").setFont(fontBold));
        references.add(new Text("T. Hobbes, ")
                .setFont(fontNormal));
        references.add(new Text("Leviathan, ")
                .setFont(fontItalic));
        references.add(new Text("Andrew Crooke, 1651.\n").setFont(fontNormal));

        references.add(new Text("[6] ").setFont(fontBold));
        references.add(new Text("T. R. Gruber, ")
                .setFont(fontNormal));
        references.add(new Text("\"A Translation Approach to Portable Ontology Specifications,\" ")
                .setFont(fontItalic));
        references.add(new Text("Knowledge Acquisition, vol. 5, no. 2, pp. 199-220, 1993.\n")
                .setFont(fontNormal));

        references.add(new Text("[7] ").setFont(fontBold));
        references.add(new Text("M. Horridge and S. Bechhofer, ")
                .setFont(fontNormal));
        references.add(new Text("\"The OWL API: A Java API for OWL Ontologies,\" ")
                .setFont(fontItalic));
        references.add(new Text("Semantic Web, vol. 2, no. 1, pp. 11-21, 2011.\n")
                .setFont(fontNormal));

        document.add(references);

        // ============================================
        // RODAPÉ
        // ============================================

        document.add(new Paragraph(" ").setFontSize(6));
        Paragraph footer = new Paragraph()
                .setTextAlignment(TextAlignment.CENTER)
                .setFontSize(7)
                .setFontColor(JT_DARK_GRAY);
        footer.add(new Text("© 2026 JokerTest-Ontology. ").setFont(fontNormal));
        footer.add(new Text("Baseado em The Dark Knight (Nolan, 2008). ").setFont(fontItalic));
        footer.add(new Text("Versão 1.0").setFont(fontNormal));
        document.add(footer);

        document.close();
        pdfDoc.close();

        System.out.println("✅ PDF gerado com sucesso!");
        System.out.println("   📁 " + outputPath);
        System.out.println("   📊 7 Questões de Competência incluídas");
    }

    // ============================================================
    // CONSTRUÇÃO DAS TABELAS
    // ============================================================

    private Table buildQ1Table(PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        Set<OWLNamedIndividual> ferries = getFerries();
        if (ferries.isEmpty()) {
            System.out.println("⚠️ Nenhuma embarcação encontrada na ontologia.");
            return null;
        }

        Table table = new Table(UnitValue.createPercentArray(new float[]{50, 50}));
        table.setWidth(UnitValue.createPercentValue(100));

        Cell questionCell = createQuestionCell("Q1", "QC1",
            "Quais embarcações participam do teste?",
            JT_CRIMSON, fontNormal, fontBold, fontItalic);
        table.addCell(questionCell);

        Cell answerCell = createAnswerCell(fontNormal, fontBold, fontItalic);
        int index = 0;

        for (OWLNamedIndividual ferry : ferries) {
            index++;
            String nome = getName(ferry);
            String desc = getDataValue(ferry, dphHasDescription);
            String source = getDataValue(ferry, dphHasSource);
            String impedida = getDataValue(ferry, dphFoiImpedidaExplosao);

            Paragraph itemP = new Paragraph();
            itemP.add(new Text(index + ". ").setFont(fontBold).setFontSize(8));
            itemP.add(new Text(nome).setFont(fontBold).setFontSize(8));
            if (impedida != null) {
                itemP.add(new Text(" [Explosão impedida: " + impedida + "]")
                    .setFont(fontItalic).setFontSize(7));
            }
            answerCell.add(itemP);

            if (desc != null && !desc.isEmpty()) {
                Paragraph descP = new Paragraph();
                descP.add(new Text("   " + desc).setFont(fontNormal).setFontSize(7));
                answerCell.add(descP);
            }

            if (source != null && !source.isEmpty()) {
                Paragraph srcP = new Paragraph();
                srcP.add(new Text("   Fonte: ").setFont(fontItalic).setFontSize(7));
                srcP.add(new Text(source).setFont(fontNormal).setFontSize(7));
                answerCell.add(srcP);
            }

            Set<OWLNamedIndividual> passengers = getPassengersOf(ferry);
            if (!passengers.isEmpty()) {
                Paragraph passP = new Paragraph();
                passP.add(new Text("   Passageiros: ").setFont(fontItalic).setFontSize(7));
                for (OWLNamedIndividual p : passengers) {
                    passP.add(new Text("[" + getName(p) + "] ").setFont(fontNormal).setFontSize(7));
                }
                answerCell.add(passP);
            }

            answerCell.add(new Paragraph(" ").setFontSize(1));
        }

        table.addCell(answerCell);
        return table;
    }

    private Table buildQ2Table(PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        Set<OWLNamedIndividual> ferries = getFerries();
        if (ferries.isEmpty()) {
            System.out.println("⚠️ Nenhuma embarcação encontrada na ontologia.");
            return null;
        }

        Table table = new Table(UnitValue.createPercentArray(new float[]{50, 50}));
        table.setWidth(UnitValue.createPercentValue(100));

        Cell questionCell = createQuestionCell("Q2", "QC2",
            "Quais passageiros estão em cada embarcação?",
            JT_GREEN, fontNormal, fontBold, fontItalic);
        table.addCell(questionCell);

        Cell answerCell = createAnswerCell(fontNormal, fontBold, fontItalic);

        int ferryIndex = 0;
        for (OWLNamedIndividual ferry : ferries) {
            ferryIndex++;
            String ferryName = getName(ferry);

            Paragraph ferryP = new Paragraph();
            ferryP.add(new Text(ferryIndex + ". ").setFont(fontBold).setFontSize(9));
            ferryP.add(new Text(ferryName).setFont(fontBold).setFontSize(9).setFontColor(JT_PURPLE));
            answerCell.add(ferryP);

            Set<OWLNamedIndividual> passengers = getPassengersOf(ferry);
            if (passengers.isEmpty()) {
                answerCell.add(new Paragraph("     (nenhum passageiro registrado)")
                    .setFont(fontItalic).setFontSize(7));
            } else {
                int pIndex = 0;
                for (OWLNamedIndividual p : passengers) {
                    pIndex++;
                    String nome = getName(p);
                    String desc = getDataValue(p, dphHasDescription);
                    String tipo = p.getIRI().getShortForm().replaceAll("\\d+$", "");

                    Paragraph itemP = new Paragraph();
                    itemP.add(new Text("     " + pIndex + ". ").setFont(fontBold).setFontSize(7));
                    itemP.add(new Text(nome).setFont(fontNormal).setFontSize(7));
                    itemP.add(new Text(" [Tipo: " + tipo + "]").setFont(fontItalic).setFontSize(7));
                    answerCell.add(itemP);

                    if (desc != null && !desc.isEmpty()) {
                        Paragraph descP = new Paragraph();
                        descP.add(new Text("        " + desc).setFont(fontNormal).setFontSize(7));
                        answerCell.add(descP);
                    }
                }
            }

            answerCell.add(new Paragraph(" ").setFontSize(2));
        }

        table.addCell(answerCell);
        return table;
    }

    private Table buildQ3Table(PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        Set<OWLNamedIndividual> ferries = getFerries();
        if (ferries.isEmpty()) {
            System.out.println("⚠️ Nenhuma embarcação encontrada na ontologia.");
            return null;
        }

        Table table = new Table(UnitValue.createPercentArray(new float[]{50, 50}));
        table.setWidth(UnitValue.createPercentValue(100));

        Cell questionCell = createQuestionCell("Q3", "QC3",
            "Quem detém o detonador de cada embarcação?",
            JT_GOLD, fontNormal, fontBold, fontItalic);
        table.addCell(questionCell);

        Cell answerCell = createAnswerCell(fontNormal, fontBold, fontItalic);

        int index = 0;
        for (OWLNamedIndividual ferry : ferries) {
            index++;
            String nome = getName(ferry);

            Paragraph ferryP = new Paragraph();
            ferryP.add(new Text(index + ". ").setFont(fontBold).setFontSize(9));
            ferryP.add(new Text(nome).setFont(fontBold).setFontSize(9).setFontColor(JT_PURPLE));
            answerCell.add(ferryP);

            Set<OWLNamedIndividual> detonators = getRelated(ferry, propTemDetonador);
            if (detonators.isEmpty()) {
                answerCell.add(new Paragraph("     (nenhum detonador registrado)")
                    .setFont(fontItalic).setFontSize(7));
            }

            for (OWLNamedIndividual det : detonators) {
                Paragraph detP = new Paragraph();
                detP.add(new Text("     Detonador: ").setFont(fontItalic).setFontSize(7));
                detP.add(new Text(getName(det)).setFont(fontBold).setFontSize(7));
                answerCell.add(detP);

                Set<OWLNamedIndividual> controllers = getRelatedInverse(det, propAciona);
                if (!controllers.isEmpty()) {
                    Paragraph ctrlP = new Paragraph();
                    ctrlP.add(new Text("     Detentor: ").setFont(fontItalic).setFontSize(7));
                    for (OWLNamedIndividual c : controllers) {
                        ctrlP.add(new Text("[" + getName(c) + "] ").setFont(fontNormal).setFontSize(7));
                    }
                    answerCell.add(ctrlP);
                }

                Set<OWLNamedIndividual> targets = getRelated(det, propControlaEmbarcacao);
                if (!targets.isEmpty()) {
                    Paragraph tgtP = new Paragraph();
                    tgtP.add(new Text("     Controla explosão de: ").setFont(fontItalic).setFontSize(7));
                    for (OWLNamedIndividual t : targets) {
                        tgtP.add(new Text("[" + getName(t) + "] ").setFont(fontNormal).setFontSize(7));
                    }
                    answerCell.add(tgtP);
                }

                String acionado = getDataValue(det, dphDetonadorAcionado);
                if (acionado != null) {
                    Paragraph acP = new Paragraph();
                    acP.add(new Text("     Foi acionado? ").setFont(fontItalic).setFontSize(7));
                    acP.add(new Text(acionado).setFont(fontBold).setFontSize(7)
                        .setFontColor("true".equalsIgnoreCase(acionado) ? JT_CRIMSON : JT_GREEN));
                    answerCell.add(acP);
                }
            }

            answerCell.add(new Paragraph(" ").setFontSize(2));
        }

        table.addCell(answerCell);
        return table;
    }

    private Table buildQ4Table(PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        Set<OWLNamedIndividual> detonators = getDetonators();
        Set<OWLNamedIndividual> ferries = getFerries();
        Set<OWLNamedIndividual> bombs = getBombs();

        Table table = new Table(UnitValue.createPercentArray(new float[]{50, 50}));
        table.setWidth(UnitValue.createPercentValue(100));

        Cell questionCell = createQuestionCell("Q4", "QC4",
            "Qual foi o resultado do teste (algum detonador foi acionado)?",
            JT_TEAL, fontNormal, fontBold, fontItalic);
        table.addCell(questionCell);

        Cell answerCell = createAnswerCell(fontNormal, fontBold, fontItalic);

        Paragraph title1 = new Paragraph("Detonadores:")
                .setFont(fontBold).setFontSize(8).setFontColor(JT_DARK_GRAY);
        answerCell.add(title1);

        for (OWLNamedIndividual det : detonators) {
            String nome = getName(det);
            String acionado = getDataValue(det, dphDetonadorAcionado);
            Paragraph p = new Paragraph();
            p.add(new Text("   • ").setFont(fontNormal).setFontSize(7));
            p.add(new Text(nome).setFont(fontBold).setFontSize(7));
            p.add(new Text(" → Acionado? ").setFont(fontItalic).setFontSize(7));
            p.add(new Text(acionado != null ? acionado : "N/A")
                .setFont(fontBold).setFontSize(7)
                .setFontColor("true".equalsIgnoreCase(acionado) ? JT_CRIMSON : JT_GREEN));
            answerCell.add(p);
        }

        answerCell.add(new Paragraph(" ").setFontSize(2));
        Paragraph title2 = new Paragraph("Bombas:")
                .setFont(fontBold).setFontSize(8).setFontColor(JT_DARK_GRAY);
        answerCell.add(title2);

        for (OWLNamedIndividual bomba : bombs) {
            String nome = getName(bomba);
            String impedida = getDataValue(bomba, dphFoiImpedidaExplosao);
            Paragraph p = new Paragraph();
            p.add(new Text("   • ").setFont(fontNormal).setFontSize(7));
            p.add(new Text(nome).setFont(fontBold).setFontSize(7));
            p.add(new Text(" → Explosão impedida? ").setFont(fontItalic).setFontSize(7));
            p.add(new Text(impedida != null ? impedida : "N/A")
                .setFont(fontBold).setFontSize(7)
                .setFontColor("true".equalsIgnoreCase(impedida) ? JT_GREEN : JT_CRIMSON));
            answerCell.add(p);
        }

        answerCell.add(new Paragraph(" ").setFontSize(2));
        Paragraph title3 = new Paragraph("Embarcações:")
                .setFont(fontBold).setFontSize(8).setFontColor(JT_DARK_GRAY);
        answerCell.add(title3);

        for (OWLNamedIndividual ferry : ferries) {
            String nome = getName(ferry);
            String impedida = getDataValue(ferry, dphFoiImpedidaExplosao);
            Paragraph p = new Paragraph();
            p.add(new Text("   • ").setFont(fontNormal).setFontSize(7));
            p.add(new Text(nome).setFont(fontBold).setFontSize(7));
            p.add(new Text(" → Salva? ").setFont(fontItalic).setFontSize(7));
            p.add(new Text(impedida != null ? impedida : "N/A")
                .setFont(fontBold).setFontSize(7)
                .setFontColor("true".equalsIgnoreCase(impedida) ? JT_GREEN : JT_CRIMSON));
            answerCell.add(p);
        }

        answerCell.add(new Paragraph(" ").setFontSize(3));
        Paragraph interp = new Paragraph()
            .setFont(fontItalic).setFontSize(7).setFontColor(JT_DARK_GRAY);
        interp.add(new Text("Interpretação: ").setFont(fontBold));
        interp.add(new Text("Nenhum detonador foi acionado. Batman impediu a explosão final. "
            + "Ambas as embarcações foram salvas."));
        answerCell.add(interp);

        table.addCell(answerCell);
        return table;
    }

    private Table buildQ5Table(PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        Set<OWLNamedIndividual> passengers = getPassengers();
        if (passengers.isEmpty()) {
            System.out.println("⚠️ Nenhum passageiro encontrado na ontologia.");
            return null;
        }

        Table table = new Table(UnitValue.createPercentArray(new float[]{50, 50}));
        table.setWidth(UnitValue.createPercentValue(100));

        Cell questionCell = createQuestionCell("Q5", "QC5",
            "Quais passageiros sobreviveram?",
            JT_GREEN, fontNormal, fontBold, fontItalic);
        table.addCell(questionCell);

        Cell answerCell = createAnswerCell(fontNormal, fontBold, fontItalic);

        int count = 0;
        for (OWLNamedIndividual p : passengers) {
            boolean survived = false;
            Set<OWLNamedIndividual> ferries = getFerryOf(p);
            for (OWLNamedIndividual ferry : ferries) {
                String impedida = getDataValue(ferry, dphFoiImpedidaExplosao);
                if ("true".equalsIgnoreCase(impedida)) {
                    survived = true;
                    break;
                }
            }
            Set<OWLNamedIndividual> sobrev = getRelated(p, propSobreviveu);
            if (!sobrev.isEmpty()) survived = true;

            if (survived) {
                count++;
                String nome = getName(p);
                String desc = getDataValue(p, dphHasDescription);
                String tipo = p.getIRI().getShortForm().replaceAll("\\d+$", "");

                Paragraph itemP = new Paragraph();
                itemP.add(new Text(count + ". ").setFont(fontBold).setFontSize(8));
                itemP.add(new Text(nome).setFont(fontBold).setFontSize(8).setFontColor(JT_GREEN));
                itemP.add(new Text(" [Tipo: " + tipo + "]").setFont(fontItalic).setFontSize(7));
                answerCell.add(itemP);

                if (desc != null && !desc.isEmpty()) {
                    answerCell.add(new Paragraph("   " + desc)
                        .setFont(fontNormal).setFontSize(7));
                }
                answerCell.add(new Paragraph(" ").setFontSize(1));
            }
        }

        if (count == 0) {
            answerCell.add(new Paragraph("(nenhum sobrevivente registrado)")
                .setFont(fontItalic).setFontSize(7));
        } else {
            answerCell.add(new Paragraph(" ").setFontSize(2));
            Paragraph total = new Paragraph("Total de sobreviventes: " + count)
                .setFont(fontBold).setFontSize(8).setFontColor(JT_GREEN);
            answerCell.add(total);
        }

        table.addCell(answerCell);
        return table;
    }

    private Table buildQ6Table(PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        Set<OWLNamedIndividual> passengers = getPassengers();
        if (passengers.isEmpty()) {
            System.out.println("⚠️ Nenhum passageiro encontrado na ontologia.");
            return null;
        }

        Table table = new Table(UnitValue.createPercentArray(new float[]{50, 50}));
        table.setWidth(UnitValue.createPercentValue(100));

        Cell questionCell = createQuestionCell("Q6", "QC6",
            "Quais passageiros morreram?",
            JT_DARK_RED, fontNormal, fontBold, fontItalic);
        table.addCell(questionCell);

        Cell answerCell = createAnswerCell(fontNormal, fontBold, fontItalic);

        int count = 0;
        for (OWLNamedIndividual p : passengers) {
            boolean died = false;
            Set<OWLNamedIndividual> ferries = getFerryOf(p);
            for (OWLNamedIndividual ferry : ferries) {
                String impedida = getDataValue(ferry, dphFoiImpedidaExplosao);
                if ("false".equalsIgnoreCase(impedida)) {
                    died = true;
                    break;
                }
            }
            Set<OWLNamedIndividual> mortos = getRelated(p, propMorreu);
            if (!mortos.isEmpty()) died = true;

            if (died) {
                count++;
                String nome = getName(p);
                String desc = getDataValue(p, dphHasDescription);
                String tipo = p.getIRI().getShortForm().replaceAll("\\d+$", "");

                Paragraph itemP = new Paragraph();
                itemP.add(new Text(count + ". ").setFont(fontBold).setFontSize(8));
                itemP.add(new Text(nome).setFont(fontBold).setFontSize(8).setFontColor(JT_DARK_RED));
                itemP.add(new Text(" [Tipo: " + tipo + "]").setFont(fontItalic).setFontSize(7));
                answerCell.add(itemP);

                if (desc != null && !desc.isEmpty()) {
                    answerCell.add(new Paragraph("   " + desc)
                        .setFont(fontNormal).setFontSize(7));
                }
                answerCell.add(new Paragraph(" ").setFontSize(1));
            }
        }

        if (count == 0) {
            answerCell.add(new Paragraph("(nenhum passageiro morreu — Batman impediu a explosão)")
                .setFont(fontItalic).setFontSize(7).setFontColor(JT_GREEN));
            answerCell.add(new Paragraph(" ").setFontSize(3));
            Paragraph note = new Paragraph()
                .setFont(fontItalic).setFontSize(7).setFontColor(JT_DARK_GRAY);
            note.add(new Text("No cenário canônico do filme, todos os 6 passageiros sobreviveram.")
                .setFont(fontBold));
            answerCell.add(note);
        } else {
            answerCell.add(new Paragraph(" ").setFontSize(2));
            Paragraph total = new Paragraph("Total de mortos: " + count)
                .setFont(fontBold).setFontSize(8).setFontColor(JT_DARK_RED);
            answerCell.add(total);
        }

        table.addCell(answerCell);
        return table;
    }

    private Table buildQ7Table(PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        Table table = new Table(UnitValue.createPercentArray(new float[]{50, 50}));
        table.setWidth(UnitValue.createPercentValue(100));

        Cell questionCell = createQuestionCell("Q7", "QC7",
            "A hipótese do Coringa foi confirmada?",
            JT_PURPLE, fontNormal, fontBold, fontItalic);
        table.addCell(questionCell);

        Cell answerCell = createAnswerCell(fontNormal, fontBold, fontItalic);

        Set<OWLNamedIndividual> hypotheses = getIndividualsByPrefix("Hipotese_");
        for (OWLNamedIndividual hyp : hypotheses) {
            String nome = getName(hyp);
            String desc = getDataValue(hyp, dphHasDescription);
            String confirmada = getDataValue(hyp, dphHipoteseConfirmada);

            Paragraph hP = new Paragraph();
            hP.add(new Text("Hipótese: ").setFont(fontItalic).setFontSize(7));
            hP.add(new Text(nome).setFont(fontBold).setFontSize(8));
            answerCell.add(hP);

            if (desc != null && !desc.isEmpty()) {
                answerCell.add(new Paragraph("   " + desc)
                    .setFont(fontNormal).setFontSize(7));
            }

            if (confirmada != null) {
                Paragraph cP = new Paragraph();
                cP.add(new Text("   Confirmada? ").setFont(fontItalic).setFontSize(7));
                cP.add(new Text(confirmada).setFont(fontBold).setFontSize(8)
                    .setFontColor("true".equalsIgnoreCase(confirmada) ? JT_CRIMSON : JT_GREEN));
                answerCell.add(cP);
            }
        }

        Set<OWLNamedIndividual> testes = getIndividualsByPrefix("Teste_");
        for (OWLNamedIndividual teste : testes) {
            String hipoteseConf = getDataValue(teste, dphHipoteseConfirmada);
            String score = getDataValue(teste, dphHasScoreMoral);

            answerCell.add(new Paragraph(" ").setFontSize(2));
            Paragraph tP = new Paragraph();
            tP.add(new Text("Teste: ").setFont(fontItalic).setFontSize(7));
            tP.add(new Text(getName(teste)).setFont(fontBold).setFontSize(8));
            answerCell.add(tP);

            if (hipoteseConf != null) {
                Paragraph hcP = new Paragraph();
                hcP.add(new Text("   Hipótese confirmada? ").setFont(fontItalic).setFontSize(7));
                hcP.add(new Text(hipoteseConf).setFont(fontBold).setFontSize(8)
                    .setFontColor("true".equalsIgnoreCase(hipoteseConf) ? JT_CRIMSON : JT_GREEN));
                answerCell.add(hcP);
            }

            if (score != null) {
                Paragraph sP = new Paragraph();
                sP.add(new Text("   Score moral: ").setFont(fontItalic).setFontSize(7));
                sP.add(new Text(score).setFont(fontNormal).setFontSize(7));
                answerCell.add(sP);
            }
        }

        answerCell.add(new Paragraph(" ").setFontSize(3));
        Paragraph interp = new Paragraph()
            .setFont(fontItalic).setFontSize(7).setFontColor(JT_DARK_GRAY);
        interp.add(new Text("Interpretação: ").setFont(fontBold));
        interp.add(new Text("A hipótese do Coringa NÃO foi confirmada. Nenhum detonador foi "
            + "acionado em nenhuma embarcação. A cooperação e a empatia prevaleceram sobre o "
            + "instinto de autopreservação, refutando a visão cínica do Coringa sobre a natureza humana."));
        answerCell.add(interp);

        table.addCell(answerCell);
        return table;
    }

    // ============================================================
    // MÉTODOS AUXILIARES
    // ============================================================

    private Cell createQuestionCell(String qId, String rq, String question, Color color,
                                   PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        Cell questionCell = new Cell();
        questionCell.setBackgroundColor(color);
        questionCell.setPadding(12);
        questionCell.setBorder(null);

        Paragraph qIdP = new Paragraph(qId)
                .setFont(fontBold)
                .setFontSize(16)
                .setFontColor(DeviceRgb.WHITE)
                .setTextAlignment(TextAlignment.CENTER);
        questionCell.add(qIdP);

        Paragraph rqP = new Paragraph("Questão: " + rq)
                .setFont(fontItalic)
                .setFontSize(8)
                .setFontColor(DeviceRgb.WHITE)
                .setTextAlignment(TextAlignment.CENTER);
        questionCell.add(rqP);

        Paragraph qcQuestion = new Paragraph(question)
                .setFont(fontNormal)
                .setFontSize(8)
                .setFontColor(DeviceRgb.WHITE)
                .setTextAlignment(TextAlignment.LEFT)
                .setMarginTop(6);
        questionCell.add(qcQuestion);

        return questionCell;
    }

    private Cell createAnswerCell(PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        Cell answerCell = new Cell();
        answerCell.setPadding(12);
        answerCell.setBorder(null);
        answerCell.setBackgroundColor(JT_LIGHT_PURPLE);

        Paragraph answerTitle = new Paragraph("RESPOSTA")
                .setFont(fontBold)
                .setFontSize(9)
                .setFontColor(JT_DARK_GRAY);
        answerCell.add(answerTitle);

        return answerCell;
    }

    // ============================================================
    // MAIN
    // ============================================================
    public static void main(String[] args) {
        try {
            JokerTestPDFGenerator generator = new JokerTestPDFGenerator();
            String outputPath =
                "D:/EclipseLunar/workspace/TestePsicologicoBatman_2/ontology/jokertest-ieee-2026.pdf";
            generator.generatePDF(outputPath);
            System.out.println("\n✅ PDF gerado com sucesso em: " + outputPath);
        } catch (Exception e) {
            System.err.println("❌ Erro: " + e.getMessage());
            e.printStackTrace();
        }
    }
}