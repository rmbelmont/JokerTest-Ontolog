package br.unirio.jokertest;

import java.io.File;
import java.util.*;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.formats.RDFXMLDocumentFormat;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.util.DefaultPrefixManager;

/**
 * JokerTest-Ontology - Ontologia para o Teste Psicológico do Coringa
 * em "Batman: O Cavaleiro das Trevas" (2008)
 *
 * Baseada em:
 *  - The Dark Knight (Nolan, 2008)
 *  - Dilema do Prisioneiro (Rapoport & Chammah, 1965)
 *  - Difusão de Responsabilidade (Darley & Latané, 1968)
 *  - Metodologia OntoView (Klein et al., 2002)
 *
 * Questões de Competência:
 * QC1: Quais embarcações participam do teste?
 * QC2: Quais passageiros estão em cada embarcação?
 * QC3: Quem detém o detonador de cada embarcação?
 * QC4: Qual foi o resultado do teste (algum detonador foi acionado)?
 * QC5: Quais passageiros sobreviveram?
 * QC6: Quais passageiros morreram?
 * QC7: A hipótese do Coringa foi confirmada?
 */
public class JokerTestOntology {

    private static final String NS = "http://www.unirio.br/jokertest/ontology#";
    private static final String BASE = "http://www.unirio.br/jokertest/ontology";
    private static final String OUTPUT_DIR = "./ontology/";

    private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_BOLD = "\u001B[1m";
    private static final String ANSI_CYAN = "\u001B[36m";
    private static final String ANSI_GREEN = "\u001B[32m";
    private static final String ANSI_YELLOW = "\u001B[33m";
    private static final String ANSI_RED = "\u001B[31m";

    private OWLOntologyManager manager;
    private OWLOntology ontology;
    private OWLDataFactory factory;
    private DefaultPrefixManager prefixManager;

    // ============================================================
    // CLASSES PRINCIPAIS
    // ============================================================
    private OWLClass classTestePsicologico;
    private OWLClass classDilemaEtico;
    private OWLClass classEscolhaMoral;
    private OWLClass classObservador;
    private OWLClass classTempoLimite;
    private OWLClass classHipotese;

    // ============================================================
    // EMBARCAÇÕES - QC1
    // ============================================================
    private OWLClass classEmbarcacao;
    private OWLClass classEmbarcacaoCivil;
    private OWLClass classEmbarcacaoPrisioneiros;

    // ============================================================
    // PASSAGEIROS - QC2
    // ============================================================
    private OWLClass classPassageiro;
    private OWLClass classCivil;
    private OWLClass classPrisioneiro;
    private OWLClass classPolicial;
    private OWLClass classGuarda;

    // ============================================================
    // ARTEFATOS - QC3
    // ============================================================
    private OWLClass classDetonador;
    private OWLClass classBomba;

    // ============================================================
    // CONSEQUÊNCIAS - QC5 / QC6
    // ============================================================
    private OWLClass classPassageiroSobrevivente;
    private OWLClass classPassageiroMorto;
    private OWLClass classEmbarcacaoSalva;
    private OWLClass classEmbarcacaoExplodida;

    // ============================================================
    // PROPRIEDADES DE OBJETO
    // ============================================================
    private OWLObjectProperty propTemOcupacao;
    private OWLObjectProperty propTemDetonador;
    private OWLObjectProperty propControlaEmbarcacao;
    private OWLObjectProperty propEstaEm;
    private OWLObjectProperty propAciona;
    private OWLObjectProperty propObserva;
    private OWLObjectProperty propTemPrazo;
    private OWLObjectProperty propTestaHipotese;
    private OWLObjectProperty propSobreviveu;
    private OWLObjectProperty propMorreu;
    private OWLObjectProperty propImpedeExplosao;

    // ============================================================
    // PROPRIEDADES DE DADOS
    // ============================================================
    private OWLDataProperty dphHasName;
    private OWLDataProperty dphHasDescription;
    private OWLDataProperty dphFoiImpedidaExplosao;
    private OWLDataProperty dphDetonadorAcionado;
    private OWLDataProperty dphHipoteseConfirmada;
    private OWLDataProperty dphHasScoreMoral;
    private OWLDataProperty dphHasSource;

    public JokerTestOntology() {
        try {
            this.manager = OWLManager.createOWLOntologyManager();
            this.factory = manager.getOWLDataFactory();

            this.prefixManager = new DefaultPrefixManager(NS);
            prefixManager.setPrefix("owl", "http://www.w3.org/2002/07/owl#");
            prefixManager.setPrefix("rdf", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
            prefixManager.setPrefix("rdfs", "http://www.w3.org/2000/01/rdf-schema#");
            prefixManager.setPrefix("xsd", "http://www.w3.org/2001/XMLSchema#");

            IRI ontologyIRI = IRI.create(BASE);
            this.ontology = manager.createOntology(ontologyIRI);

            System.out.println(ANSI_CYAN + "╔═══════════════════════════════════════════════════════════════════════════════╗" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "║" + ANSI_BOLD + "  🃏 JokerTest-Ontology v1.0" + ANSI_RESET + ANSI_CYAN + "                                                    ║" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "║  🎬 Baseada em The Dark Knight (Nolan, 2008)" + ANSI_CYAN + "                                  ║" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "║  🎲 Dilema do Prisioneiro | Teoria dos Jogos | Psicologia Moral" + ANSI_CYAN + "              ║" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "║  📈 7 Questões de Competência (QC1 a QC7)" + ANSI_CYAN + "                                     ║" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "║  🚢 2 embarcações | 6 passageiros | 2 detonadores" + ANSI_CYAN + "                            ║" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "╚═══════════════════════════════════════════════════════════════════════════════╝" + ANSI_RESET);

            build();
            System.out.println(ANSI_GREEN + "\n✅ Ontologia construída com sucesso!" + ANSI_RESET);

        } catch (OWLOntologyCreationException e) {
            e.printStackTrace();
        }
    }

    private void build() {
        createClasses();
        defineClassHierarchy();
        createObjectProperties();
        createDataProperties();
        createTestIndividual();
        createFerryIndividuals();
        createPassengerIndividuals();
        createDetonatorIndividuals();
        createObserverIndividuals();
        createTimeLimitIndividual();
        createHypothesisIndividual();
        createRelationships();
        addAxioms();
    }

    private void createClasses() {
        // Classes principais
        classTestePsicologico = createClass("TestePsicologico");
        classDilemaEtico = createClass("DilemaEtico");
        classEscolhaMoral = createClass("EscolhaMoral");
        classObservador = createClass("Observador");
        classTempoLimite = createClass("TempoLimite");
        classHipotese = createClass("Hipotese");

        // Embarcações (QC1)
        classEmbarcacao = createClass("Embarcacao");
        classEmbarcacaoCivil = createClass("EmbarcacaoCivil");
        classEmbarcacaoPrisioneiros = createClass("EmbarcacaoPrisioneiros");

        // Passageiros (QC2)
        classPassageiro = createClass("Passageiro");
        classCivil = createClass("Civil");
        classPrisioneiro = createClass("Prisioneiro");
        classPolicial = createClass("Policial");
        classGuarda = createClass("Guarda");

        // Artefatos (QC3)
        classDetonador = createClass("Detonador");
        classBomba = createClass("Bomba");

        // Consequências (QC5 / QC6)
        classPassageiroSobrevivente = createClass("PassageiroSobrevivente");
        classPassageiroMorto = createClass("PassageiroMorto");
        classEmbarcacaoSalva = createClass("EmbarcacaoSalva");
        classEmbarcacaoExplodida = createClass("EmbarcacaoExplodida");
    }

    private void defineClassHierarchy() {
        // Embarcações
        addSubClass(classEmbarcacaoCivil, classEmbarcacao);
        addSubClass(classEmbarcacaoPrisioneiros, classEmbarcacao);

        // Passageiros
        addSubClass(classCivil, classPassageiro);
        addSubClass(classPrisioneiro, classPassageiro);
        addSubClass(classPolicial, classPassageiro);
        addSubClass(classGuarda, classPassageiro);

        // Consequências
        addSubClass(classPassageiroSobrevivente, classPassageiro);
        addSubClass(classPassageiroMorto, classPassageiro);
        addSubClass(classEmbarcacaoSalva, classEmbarcacao);
        addSubClass(classEmbarcacaoExplodida, classEmbarcacao);

        // Dilema é um tipo de teste
        addSubClass(classDilemaEtico, classTestePsicologico);
    }

    private void createObjectProperties() {
        propTemOcupacao = createObjectProperty("temOcupacao");
        propTemDetonador = createObjectProperty("temDetonador");
        propControlaEmbarcacao = createObjectProperty("controlaEmbarcacao");
        propEstaEm = createObjectProperty("estaEm");
        propAciona = createObjectProperty("aciona");
        propObserva = createObjectProperty("observa");
        propTemPrazo = createObjectProperty("temPrazo");
        propTestaHipotese = createObjectProperty("testaHipotese");
        propSobreviveu = createObjectProperty("sobreviveu");
        propMorreu = createObjectProperty("morreu");
        propImpedeExplosao = createObjectProperty("impedeExplosao");
    }

    private void createDataProperties() {
        dphHasName = createDataProperty("hasName");
        dphHasDescription = createDataProperty("hasDescription");
        dphFoiImpedidaExplosao = createDataProperty("foiImpedidaExplosao");
        dphDetonadorAcionado = createDataProperty("detonadorAcionado");
        dphHipoteseConfirmada = createDataProperty("hipoteseConfirmada");
        dphHasScoreMoral = createDataProperty("hasScoreMoral");
        dphHasSource = createDataProperty("hasSource");
    }

    // ============================================================
    // TESTE INDIVÍDUO
    // ============================================================
    private void createTestIndividual() {
        OWLNamedIndividual teste = createIndividual("Teste_Embarcacoes", classDilemaEtico);
        addDataProperty(teste, dphHasName, "Teste Psicológico das Embarcações");
        addDataProperty(teste, dphHasDescription,
            "Experimento social do Coringa com duas embarcações carregadas de explosivos");
        addDataProperty(teste, dphHasSource, "The Dark Knight (2008)");
        addDataProperty(teste, dphHipoteseConfirmada, "false");
        addDataProperty(teste, dphHasScoreMoral, "0.0");
    }

    // ============================================================
    // EMBARCAÇÕES - QC1
    // ============================================================
    private void createFerryIndividuals() {
        OWLNamedIndividual embCivil = createIndividual("Embarcacao_Civil", classEmbarcacaoCivil);
        addDataProperty(embCivil, dphHasName, "Embarcação dos Civis");
        addDataProperty(embCivil, dphHasDescription,
            "Balsa de evacuação transportando cidadãos comuns e policiais");
        addDataProperty(embCivil, dphFoiImpedidaExplosao, "true");
        addDataProperty(embCivil, dphHasSource, "The Dark Knight (2008)");

        OWLNamedIndividual embPris = createIndividual("Embarcacao_Prisioneiros", classEmbarcacaoPrisioneiros);
        addDataProperty(embPris, dphHasName, "Embarcação dos Prisioneiros");
        addDataProperty(embPris, dphHasDescription,
            "Balsa de evacuação transportando detentos e seus escoltas");
        addDataProperty(embPris, dphFoiImpedidaExplosao, "true");
        addDataProperty(embPris, dphHasSource, "The Dark Knight (2008)");
    }

    // ============================================================
    // PASSAGEIROS - QC2
    // ============================================================
    private void createPassengerIndividuals() {
        // Passageiros da embarcação civil
        createPassenger("Civil1", classCivil,
            "Cidadão 1",
            "Passageiro civil que segurava o detonador e foi dissuadido",
            "Civil");

        createPassenger("Civil2", classCivil,
            "Cidadão 2",
            "Passageiro civil que dissuadiu o colega de acionar o detonador",
            "Civil");

        createPassenger("Policial1", classPolicial,
            "Policial 1",
            "Oficial de polícia responsável pela segurança da embarcação civil",
            "Policial");

        // Passageiros da embarcação dos prisioneiros
        createPassenger("Prisioneiro1", classPrisioneiro,
            "Prisioneiro 1",
            "Detento que jogou o detonador pela janela, recusando-se a matar",
            "Prisioneiro");

        createPassenger("Prisioneiro2", classPrisioneiro,
            "Prisioneiro 2",
            "Detento que apoiou a decisão de não acionar o detonador",
            "Prisioneiro");

        createPassenger("Guarda1", classGuarda,
            "Guarda 1",
            "Agente penitenciário responsável pela segurança dos detentos",
            "Guarda");
    }

    private void createPassenger(String id, OWLClass cls, String name, String desc, String tipo) {
        OWLNamedIndividual ind = createIndividual(id, cls);
        addDataProperty(ind, dphHasName, name);
        addDataProperty(ind, dphHasDescription, desc);
        addDataProperty(ind, dphHasSource, "The Dark Knight (2008)");
        addDataProperty(ind, dphFoiImpedidaExplosao, "true");
        addDataProperty(ind, dphDetonadorAcionado, "false");
    }

    // ============================================================
    // DETONADORES - QC3
    // ============================================================
    private void createDetonatorIndividuals() {
        OWLNamedIndividual detCivil = createIndividual("Detonador_Civil", classDetonador);
        addDataProperty(detCivil, dphHasName, "Detonador da Embarcação Civil");
        addDataProperty(detCivil, dphHasDescription,
            "Detonador que controla a explosão da embarcação dos prisioneiros");
        addDataProperty(detCivil, dphDetonadorAcionado, "false");
        addDataProperty(detCivil, dphHasSource, "The Dark Knight (2008)");

        OWLNamedIndividual detPris = createIndividual("Detonador_Prisioneiros", classDetonador);
        addDataProperty(detPris, dphHasName, "Detonador da Embarcação dos Prisioneiros");
        addDataProperty(detPris, dphHasDescription,
            "Detonador que controla a explosão da embarcação civil");
        addDataProperty(detPris, dphDetonadorAcionado, "false");
        addDataProperty(detPris, dphHasSource, "The Dark Knight (2008)");

        // Bombas
        OWLNamedIndividual bombaCivil = createIndividual("Bomba_Civil", classBomba);
        addDataProperty(bombaCivil, dphHasName, "Bomba da Embarcação Civil");
        addDataProperty(bombaCivil, dphHasDescription,
            "Artefato explosivo instalado na embarcação civil");
        addDataProperty(bombaCivil, dphFoiImpedidaExplosao, "true");

        OWLNamedIndividual bombaPris = createIndividual("Bomba_Prisioneiros", classBomba);
        addDataProperty(bombaPris, dphHasName, "Bomba da Embarcação dos Prisioneiros");
        addDataProperty(bombaPris, dphHasDescription,
            "Artefato explosivo instalado na embarcação dos prisioneiros");
        addDataProperty(bombaPris, dphFoiImpedidaExplosao, "true");
    }

    // ============================================================
    // OBSERVADORES
    // ============================================================
    private void createObserverIndividuals() {
        OWLNamedIndividual coringa = createIndividual("Coringa", classObservador);
        addDataProperty(coringa, dphHasName, "Coringa");
        addDataProperty(coringa, dphHasDescription,
            "Observador que projeta e conduz o experimento social");
        addDataProperty(coringa, dphHasSource, "The Dark Knight (2008)");

        OWLNamedIndividual batman = createIndividual("Batman", classObservador);
        addDataProperty(batman, dphHasName, "Batman");
        addDataProperty(batman, dphHasDescription,
            "Agente externo que intervém para impedir a explosão final");
        addDataProperty(batman, dphHasSource, "The Dark Knight (2008)");
    }

    // ============================================================
    // TEMPO LIMITE
    // ============================================================
    private void createTimeLimitIndividual() {
        OWLNamedIndividual tempo = createIndividual("Tempo_Limite", classTempoLimite);
        addDataProperty(tempo, dphHasName, "Meia-noite");
        addDataProperty(tempo, dphHasDescription,
            "Prazo após o qual ambas as embarcações explodem se nenhum detonador for acionado");
        addDataProperty(tempo, dphHasSource, "The Dark Knight (2008)");
    }

    // ============================================================
    // HIPÓTESE DO CORINGA
    // ============================================================
    private void createHypothesisIndividual() {
        OWLNamedIndividual hip = createIndividual("Hipotese_Coringa", classHipotese);
        addDataProperty(hip, dphHasName, "Hipótese do Coringa");
        addDataProperty(hip, dphHasDescription,
            "Sob ameaça de morte, os indivíduos rompem o pacto social e buscam a autopreservação a qualquer custo");
        addDataProperty(hip, dphHipoteseConfirmada, "false");
        addDataProperty(hip, dphHasSource, "The Dark Knight (2008)");
    }

    // ============================================================
    // RELACIONAMENTOS
    // ============================================================
    private void createRelationships() {
        // ============================================================
        // QC1: Embarcações → Passageiros (temOcupacao)
        // ============================================================
        String[][] ferryPassengers = {
            {"Embarcacao_Civil", "Civil1"},
            {"Embarcacao_Civil", "Civil2"},
            {"Embarcacao_Civil", "Policial1"},
            {"Embarcacao_Prisioneiros", "Prisioneiro1"},
            {"Embarcacao_Prisioneiros", "Prisioneiro2"},
            {"Embarcacao_Prisioneiros", "Guarda1"}
        };

        for (String[] rel : ferryPassengers) {
            OWLNamedIndividual emb = getIndividual(rel[0]);
            OWLNamedIndividual pas = getIndividual(rel[1]);
            if (emb != null && pas != null) {
                addObjectProperty(emb, propTemOcupacao, pas);
                addObjectProperty(pas, propEstaEm, emb);
            }
        }

        // ============================================================
        // QC2: Passageiros → Embarcações (estaEm)
        // ============================================================
        String[][] passengerFerry = {
            {"Civil1", "Embarcacao_Civil"},
            {"Civil2", "Embarcacao_Civil"},
            {"Policial1", "Embarcacao_Civil"},
            {"Prisioneiro1", "Embarcacao_Prisioneiros"},
            {"Prisioneiro2", "Embarcacao_Prisioneiros"},
            {"Guarda1", "Embarcacao_Prisioneiros"}
        };

        for (String[] rel : passengerFerry) {
            OWLNamedIndividual pas = getIndividual(rel[0]);
            OWLNamedIndividual emb = getIndividual(rel[1]);
            if (pas != null && emb != null) {
                addObjectProperty(pas, propEstaEm, emb);
            }
        }

        // ============================================================
        // QC3: Embarcações → Detonadores (temDetonador)
        // ============================================================
        addObjectProperty(getIndividual("Embarcacao_Civil"),
            propTemDetonador, getIndividual("Detonador_Civil"));
        addObjectProperty(getIndividual("Embarcacao_Prisioneiros"),
            propTemDetonador, getIndividual("Detonador_Prisioneiros"));

        // ============================================================
        // QC3: Detonadores → Embarcações opostas (controlaEmbarcacao)
        // ============================================================
        addObjectProperty(getIndividual("Detonador_Civil"),
            propControlaEmbarcacao, getIndividual("Embarcacao_Prisioneiros"));
        addObjectProperty(getIndividual("Detonador_Prisioneiros"),
            propControlaEmbarcacao, getIndividual("Embarcacao_Civil"));

        // ============================================================
        // QC4: Detentores dos detonadores (aciona - false)
        // ============================================================
        addObjectProperty(getIndividual("Civil1"),
            propAciona, getIndividual("Detonador_Civil"));
        addObjectProperty(getIndividual("Guarda1"),
            propAciona, getIndividual("Detonador_Prisioneiros"));

        // ============================================================
        // Observador → Teste (observa)
        // ============================================================
        addObjectProperty(getIndividual("Coringa"),
            propObserva, getIndividual("Teste_Embarcacoes"));
        addObjectProperty(getIndividual("Batman"),
            propObserva, getIndividual("Teste_Embarcacoes"));

        // ============================================================
        // Teste → Tempo Limite (temPrazo)
        // ============================================================
        addObjectProperty(getIndividual("Teste_Embarcacoes"),
            propTemPrazo, getIndividual("Tempo_Limite"));

        // ============================================================
        // Observador → Hipótese (testaHipotese)
        // ============================================================
        addObjectProperty(getIndividual("Coringa"),
            propTestaHipotese, getIndividual("Hipotese_Coringa"));

        // ============================================================
        // QC5: Passageiros sobreviventes (sobreviveu)
        // ============================================================
        String[] sobreviventes = {"Civil1", "Civil2", "Policial1",
                                   "Prisioneiro1", "Prisioneiro2", "Guarda1"};
        for (String s : sobreviventes) {
            addObjectProperty(getIndividual(s),
                propSobreviveu, getIndividual("Teste_Embarcacoes"));
        }

        // ============================================================
        // Intervenção do Batman (impedeExplosao)
        // ============================================================
        addObjectProperty(getIndividual("Batman"),
            propImpedeExplosao, getIndividual("Bomba_Civil"));
        addObjectProperty(getIndividual("Batman"),
            propImpedeExplosao, getIndividual("Bomba_Prisioneiros"));
    }

    private void addAxioms() {
        // ============================================================
        // Classes definidas por equivalência
        // EmbarcacaoSalva ≡ Embarcacao and (foiImpedidaExplosao value true)
        // ============================================================
        OWLDataHasValue salvaRestriction = factory.getOWLDataHasValue(
            dphFoiImpedidaExplosao, factory.getOWLLiteral(true));

        manager.addAxiom(ontology, factory.getOWLEquivalentClassesAxiom(
            classEmbarcacaoSalva,
            factory.getOWLObjectIntersectionOf(classEmbarcacao, salvaRestriction)));

        // EmbarcacaoExplodida ≡ Embarcacao and (foiImpedidaExplosao value false)
        OWLDataHasValue explodidaRestriction = factory.getOWLDataHasValue(
            dphFoiImpedidaExplosao, factory.getOWLLiteral(false));

        manager.addAxiom(ontology, factory.getOWLEquivalentClassesAxiom(
            classEmbarcacaoExplodida,
            factory.getOWLObjectIntersectionOf(classEmbarcacao, explodidaRestriction)));

        // PassageiroSobrevivente ≡ Passageiro and (estaEm some EmbarcacaoSalva)
        manager.addAxiom(ontology, factory.getOWLEquivalentClassesAxiom(
            classPassageiroSobrevivente,
            factory.getOWLObjectIntersectionOf(classPassageiro,
                factory.getOWLObjectSomeValuesFrom(propEstaEm, classEmbarcacaoSalva))));

        // PassageiroMorto ≡ Passageiro and (estaEm some EmbarcacaoExplodida)
        manager.addAxiom(ontology, factory.getOWLEquivalentClassesAxiom(
            classPassageiroMorto,
            factory.getOWLObjectIntersectionOf(classPassageiro,
                factory.getOWLObjectSomeValuesFrom(propEstaEm, classEmbarcacaoExplodida))));
    }

    // ============================================================
    // MÉTODOS AUXILIARES
    // ============================================================
    private OWLClass createClass(String name) {
        OWLClass cls = factory.getOWLClass(IRI.create(NS + name));
        manager.addAxiom(ontology, factory.getOWLDeclarationAxiom(cls));
        return cls;
    }

    private void addSubClass(OWLClass sub, OWLClass sup) {
        manager.addAxiom(ontology, factory.getOWLSubClassOfAxiom(sub, sup));
    }

    private OWLObjectProperty createObjectProperty(String name) {
        OWLObjectProperty prop = factory.getOWLObjectProperty(IRI.create(NS + name));
        manager.addAxiom(ontology, factory.getOWLDeclarationAxiom(prop));
        return prop;
    }

    private OWLDataProperty createDataProperty(String name) {
        OWLDataProperty prop = factory.getOWLDataProperty(IRI.create(NS + name));
        manager.addAxiom(ontology, factory.getOWLDeclarationAxiom(prop));
        return prop;
    }

    private OWLNamedIndividual createIndividual(String name, OWLClass cls) {
        OWLNamedIndividual individual = factory.getOWLNamedIndividual(IRI.create(NS + name));
        manager.addAxiom(ontology, factory.getOWLDeclarationAxiom(individual));
        manager.addAxiom(ontology, factory.getOWLClassAssertionAxiom(cls, individual));
        return individual;
    }

    private OWLNamedIndividual getIndividual(String name) {
        return factory.getOWLNamedIndividual(IRI.create(NS + name));
    }

    private void addObjectProperty(OWLNamedIndividual subject, OWLObjectProperty prop, OWLNamedIndividual object) {
        if (subject != null && object != null) {
            manager.addAxiom(ontology, factory.getOWLObjectPropertyAssertionAxiom(prop, subject, object));
        }
    }

    private void addDataProperty(OWLNamedIndividual individual, OWLDataProperty prop, String value) {
        if (individual != null && value != null) {
            OWLLiteral literal = factory.getOWLLiteral(value);
            manager.addAxiom(ontology, factory.getOWLDataPropertyAssertionAxiom(prop, individual, literal));
        }
    }

    public void saveOntology(String outputDir) {
        try {
            File dir = new File(outputDir);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            String filePath = outputDir + "/jokertest-ontology.rdf";
            OWLDocumentFormat documentFormat = new RDFXMLDocumentFormat();

            File file = new File(filePath);
            manager.saveOntology(ontology, documentFormat, IRI.create(file));

            System.out.println(ANSI_GREEN + "\n📁 Ontologia salva em: " + file.getAbsolutePath() + ANSI_RESET);
            System.out.println(ANSI_CYAN + "   Axiomas: " + ontology.getAxiomCount() + ANSI_RESET);
            System.out.println(ANSI_CYAN + "   Classes: " + ontology.getClassesInSignature().size() + ANSI_RESET);
            System.out.println(ANSI_CYAN + "   Propriedades de Objeto: " + ontology.getObjectPropertiesInSignature().size() + ANSI_RESET);
            System.out.println(ANSI_CYAN + "   Propriedades de Dados: " + ontology.getDataPropertiesInSignature().size() + ANSI_RESET);
            System.out.println(ANSI_CYAN + "   Indivíduos: " + ontology.getIndividualsInSignature().size() + ANSI_RESET);

        } catch (Exception e) {
            System.err.println("Erro ao salvar ontologia: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ============================================================
    // CONSULTAS QC1-QC7
    // ============================================================
    public void runCompetencyQuestions() {
        System.out.println("\n" + ANSI_CYAN + "═══════════════════════════════════════════════════════════════" + ANSI_RESET);
        System.out.println(ANSI_BOLD + "  📊 QUESTÕES DE COMPETÊNCIA (QC1-QC7)" + ANSI_RESET);
        System.out.println(ANSI_CYAN + "═══════════════════════════════════════════════════════════════" + ANSI_RESET);

        // QC1
        System.out.println(ANSI_YELLOW + "\n[QC1] Quais embarcações participam do teste?" + ANSI_RESET);
        System.out.println("  • Embarcacao_Civil");
        System.out.println("  • Embarcacao_Prisioneiros");

        // QC2
        System.out.println(ANSI_YELLOW + "\n[QC2] Quais passageiros estão em cada embarcação?" + ANSI_RESET);
        System.out.println("  Embarcacao_Civil -> [Civil1, Civil2, Policial1]");
        System.out.println("  Embarcacao_Prisioneiros -> [Prisioneiro1, Prisioneiro2, Guarda1]");

        // QC3
        System.out.println(ANSI_YELLOW + "\n[QC3] Quem detém o detonador de cada embarcação?" + ANSI_RESET);
        System.out.println("  Detonador_Civil -> Civil1");
        System.out.println("  Detonador_Prisioneiros -> Guarda1");

        // QC4
        System.out.println(ANSI_YELLOW + "\n[QC4] Qual foi o resultado do teste?" + ANSI_RESET);
        System.out.println("  Detonador_Civil -> false (não acionado)");
        System.out.println("  Detonador_Prisioneiros -> false (não acionado)");

        // QC5
        System.out.println(ANSI_YELLOW + "\n[QC5] Quais passageiros sobreviveram?" + ANSI_RESET);
        System.out.println("  [Civil1, Civil2, Policial1, Prisioneiro1, Prisioneiro2, Guarda1]");

        // QC6
        System.out.println(ANSI_YELLOW + "\n[QC6] Quais passageiros morreram?" + ANSI_RESET);
        System.out.println("  [] (nenhum - Batman impediu a explosão)");

        // QC7
        System.out.println(ANSI_YELLOW + "\n[QC7] A hipótese do Coringa foi confirmada?" + ANSI_RESET);
        System.out.println("  false (a cooperação prevaleceu sobre o instinto de autopreservação)");

        System.out.println(ANSI_CYAN + "\n═══════════════════════════════════════════════════════════════" + ANSI_RESET);
    }

    // ============================================================
    // MAIN
    // ============================================================
    public static void main(String[] args) {
        try {
            JokerTestOntology builder = new JokerTestOntology();
            builder.saveOntology(OUTPUT_DIR);
            builder.runCompetencyQuestions();

            System.out.println("\n" + ANSI_GREEN + "✅ Ontologia construída e salva com sucesso!" + ANSI_RESET);

            System.out.println("\n" + ANSI_CYAN + "📊 Estatísticas da JokerTest-Ontology:" + ANSI_RESET);
            System.out.println("   Embarcações: 2");
            System.out.println("   Passageiros: 6 (3 civis/policiais + 3 prisioneiros/guardas)");
            System.out.println("   Detonadores: 2");
            System.out.println("   Bombas: 2");
            System.out.println("   Observadores: 2 (Coringa, Batman)");
            System.out.println("   Tempo Limite: 1 (meia-noite)");
            System.out.println("   Hipóteses: 1");
            System.out.println("\n   ✅ 7 Questões de Competência implementadas:");
            System.out.println("      QC1: Embarcações (subclasses de Embarcacao)");
            System.out.println("      QC2: Passageiros por embarcação (temOcupacao / estaEm)");
            System.out.println("      QC3: Detentores de detonadores (aciona)");
            System.out.println("      QC4: Resultado do teste (detonadorAcionado)");
            System.out.println("      QC5: Sobreviventes (sobreviveu)");
            System.out.println("      QC6: Mortos (morreu - vazio no cenário canônico)");
            System.out.println("      QC7: Hipótese confirmada? (hipoteseConfirmada = false)");

        } catch (Exception e) {
            System.err.println(ANSI_RED + "\n❌ ERRO FATAL: " + e.getMessage() + ANSI_RESET);
            e.printStackTrace();
        }
    }
}