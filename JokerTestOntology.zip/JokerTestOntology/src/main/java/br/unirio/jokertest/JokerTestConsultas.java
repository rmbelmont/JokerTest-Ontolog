package br.unirio.jokertest;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;
import org.semanticweb.owlapi.search.EntitySearcher;

import java.io.File;
import java.util.*;

/**
 * JokerTestConsultas - Sistema de Consultas para JokerTest-Ontology
 *
 * Implementa as 7 Questões de Competência da ontologia do
 * Teste Psicológico do Coringa em "The Dark Knight" (2008).
 *
 * Baseado em:
 *  - The Dark Knight (Nolan, 2008)
 *  - Dilema do Prisioneiro (Rapoport & Chammah, 1965)
 *  - Difusão de Responsabilidade (Darley & Latané, 1968)
 */
public class JokerTestConsultas {

    private static final String NS = "http://www.unirio.br/jokertest/ontology#";
    private static final String SEPARATOR = "=".repeat(90);

    // ============================================================
    // CAMINHOS CORRIGIDOS
    // ============================================================
    private static final String ONTOLOGY_PATH =
        "D:/EclipseLunar/workspace/TestePsicologicoBatman_2/ontology/jokertest-ontology.rdf";

    private static final String PDF_OUTPUT_PATH =
        "D:/EclipseLunar/workspace/TestePsicologicoBatman_2/ontology/jokertest-ieee-2026.pdf";

    private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_GREEN = "\u001B[32m";
    private static final String ANSI_CYAN = "\u001B[36m";
    private static final String ANSI_YELLOW = "\u001B[33m";
    private static final String ANSI_RED = "\u001B[31m";
    private static final String ANSI_BOLD = "\u001B[1m";

    private OWLOntologyManager manager;
    private OWLOntology ontology;
    private OWLDataFactory factory;
    private OWLReasoner reasoner;
    private Scanner scanner;

    // ============================================================
    // PROPRIEDADES DE OBJETO
    // ============================================================
    private OWLObjectProperty propTemOcupacao;
    private OWLObjectProperty propTemDetonador;
    private OWLObjectProperty propControlaEmbarcacao;
    private OWLObjectProperty propEstaEm;
    private OWLObjectProperty propAciona;
    private OWLObjectProperty propObserva;
    private OWLObjectProperty propTemPrazo;
    private OWLObjectProperty propTestaHipotese;
    private OWLObjectProperty propSobreviveu;
    private OWLObjectProperty propMorreu;
    private OWLObjectProperty propImpedeExplosao;

    // ============================================================
    // PROPRIEDADES DE DADOS
    // ============================================================
    private OWLDataProperty dphHasName;
    private OWLDataProperty dphHasDescription;
    private OWLDataProperty dphFoiImpedidaExplosao;
    private OWLDataProperty dphDetonadorAcionado;
    private OWLDataProperty dphHipoteseConfirmada;
    private OWLDataProperty dphHasScoreMoral;
    private OWLDataProperty dphHasSource;

    public JokerTestConsultas() {
        this.scanner = new Scanner(System.in);
        try {
            loadOntology();
            initializeProperties();

            StructuralReasonerFactory reasonerFactory = new StructuralReasonerFactory();
            this.reasoner = reasonerFactory.createReasoner(ontology);

            System.out.println(ANSI_GREEN + "✅ Ontologia carregada com sucesso!" + ANSI_RESET);
            System.out.println("  Arquivo: " + ONTOLOGY_PATH);
            System.out.println("  Axiomas: " + ontology.getAxiomCount());
            System.out.println("  Classes: " + ontology.getClassesInSignature().size());
            System.out.println("  Indivíduos: " + ontology.getIndividualsInSignature().size());
            System.out.println();

            showMenu();

        } catch (Exception e) {
            System.err.println(ANSI_RED + "❌ Erro: " + e.getMessage() + ANSI_RESET);
            e.printStackTrace();
        }
    }

    private void loadOntology() throws Exception {
        this.manager = OWLManager.createOWLOntologyManager();
        this.factory = manager.getOWLDataFactory();

        File ontologyFile = new File(ONTOLOGY_PATH);
        if (!ontologyFile.exists()) {
            throw new Exception("Arquivo não encontrado: " + ONTOLOGY_PATH);
        }

        this.ontology = manager.loadOntologyFromOntologyDocument(ontologyFile);
        System.out.println(ANSI_GREEN + "📄 Ontologia carregada: " + ontologyFile.getName() + ANSI_RESET);
    }

    private void initializeProperties() {
        propTemOcupacao = getObjectProperty("temOcupacao");
        propTemDetonador = getObjectProperty("temDetonador");
        propControlaEmbarcacao = getObjectProperty("controlaEmbarcacao");
        propEstaEm = getObjectProperty("estaEm");
        propAciona = getObjectProperty("aciona");
        propObserva = getObjectProperty("observa");
        propTemPrazo = getObjectProperty("temPrazo");
        propTestaHipotese = getObjectProperty("testaHipotese");
        propSobreviveu = getObjectProperty("sobreviveu");
        propMorreu = getObjectProperty("morreu");
        propImpedeExplosao = getObjectProperty("impedeExplosao");

        dphHasName = getDataProperty("hasName");
        dphHasDescription = getDataProperty("hasDescription");
        dphFoiImpedidaExplosao = getDataProperty("foiImpedidaExplosao");
        dphDetonadorAcionado = getDataProperty("detonadorAcionado");
        dphHipoteseConfirmada = getDataProperty("hipoteseConfirmada");
        dphHasScoreMoral = getDataProperty("hasScoreMoral");
        dphHasSource = getDataProperty("hasSource");
    }

    private OWLObjectProperty getObjectProperty(String name) {
        return factory.getOWLObjectProperty(IRI.create(NS + name));
    }

    private OWLDataProperty getDataProperty(String name) {
        return factory.getOWLDataProperty(IRI.create(NS + name));
    }

    // ============================================================
    // MÉTODOS AUXILIARES DE CONSULTA
    // ============================================================

    private Set<OWLNamedIndividual> getIndividualsByPrefix(String prefix) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (ontology == null) return result;

        try {
            Set<OWLNamedIndividual> allInds = ontology.getIndividualsInSignature();
            for (OWLNamedIndividual ind : allInds) {
                String iri = ind.getIRI().getShortForm();
                if (iri.startsWith(prefix)) {
                    result.add(ind);
                }
            }
        } catch (Exception e) { /* ignore */ }
        return result;
    }

    private Set<OWLNamedIndividual> getFerries() {
        return getIndividualsByPrefix("Embarcacao_");
    }

    private Set<OWLNamedIndividual> getPassengers() {
        Set<OWLNamedIndividual> result = new HashSet<>();
        result.addAll(getIndividualsByPrefix("Civil"));
        result.addAll(getIndividualsByPrefix("Prisioneiro"));
        result.addAll(getIndividualsByPrefix("Policial"));
        result.addAll(getIndividualsByPrefix("Guarda"));
        return result;
    }

    private Set<OWLNamedIndividual> getDetonators() {
        return getIndividualsByPrefix("Detonador_");
    }

    private Set<OWLNamedIndividual> getBombs() {
        return getIndividualsByPrefix("Bomba_");
    }

    private Set<OWLNamedIndividual> getObservers() {
        return getIndividualsByPrefix("Coringa");
    }

    private String getDataValue(OWLNamedIndividual individual, OWLDataProperty prop) {
        if (individual == null || prop == null) return null;
        try {
            Optional<OWLLiteral> literal = EntitySearcher
                .getDataPropertyValues(individual, prop, ontology).findFirst();
            return literal.map(OWLLiteral::getLiteral).orElse(null);
        } catch (Exception e) { return null; }
    }

    private String getName(OWLNamedIndividual individual) {
        if (individual == null) return "N/A";
        String name = getDataValue(individual, dphHasName);
        if (name != null && !name.isEmpty()) return name;
        String iri = individual.getIRI().getShortForm();
        return iri.replace("_", " ");
    }

    private Set<OWLNamedIndividual> getRelated(OWLNamedIndividual individual, OWLObjectProperty prop) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (individual == null || prop == null || ontology == null) return result;

        try {
            Set<OWLObjectPropertyAssertionAxiom> axioms =
                ontology.getObjectPropertyAssertionAxioms(individual);
            for (OWLObjectPropertyAssertionAxiom axiom : axioms) {
                if (axiom.getProperty().equals(prop) && axiom.getSubject().equals(individual)) {
                    OWLIndividual object = axiom.getObject();
                    if (object instanceof OWLNamedIndividual) {
                        result.add((OWLNamedIndividual) object);
                    }
                }
            }
        } catch (Exception e) { /* ignore */ }

        return result;
    }

    private Set<OWLNamedIndividual> getRelatedInverse(OWLNamedIndividual object, OWLObjectProperty prop) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (object == null || prop == null || ontology == null) return result;

        try {
            for (OWLObjectPropertyAssertionAxiom axiom : ontology.getAxioms(AxiomType.OBJECT_PROPERTY_ASSERTION)) {
                if (axiom.getProperty().equals(prop) && axiom.getObject().equals(object)) {
                    OWLIndividual subject = axiom.getSubject();
                    if (subject instanceof OWLNamedIndividual) {
                        result.add((OWLNamedIndividual) subject);
                    }
                }
            }
        } catch (Exception e) { /* ignore */ }

        return result;
    }

    private Set<OWLNamedIndividual> getPassengersOf(OWLNamedIndividual ferry) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        result.addAll(getRelated(ferry, propTemOcupacao));
        result.addAll(getRelatedInverse(ferry, propEstaEm));
        return result;
    }

    private Set<OWLNamedIndividual> getFerryOf(OWLNamedIndividual passenger) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        result.addAll(getRelated(passenger, propEstaEm));
        result.addAll(getRelatedInverse(passenger, propTemOcupacao));
        return result;
    }

    // ============================================================
    // EXIBIÇÃO DAS QUESTÕES DE COMPETÊNCIA
    // ============================================================

    private void displayQC1() {
        printHeader("QC1 - Quais embarcações participam do teste?");

        Set<OWLNamedIndividual> ferries = getFerries();

        System.out.println("\n  🚢 Total de Embarcações: " + ferries.size() + "\n");
        System.out.println("  " + "-".repeat(80));

        int count = 0;
        for (OWLNamedIndividual ferry : ferries) {
            count++;
            String nome = getName(ferry);
            String desc = getDataValue(ferry, dphHasDescription);
            String source = getDataValue(ferry, dphHasSource);
            String impedida = getDataValue(ferry, dphFoiImpedidaExplosao);

            System.out.printf("  %d. %s%n", count, nome);
            if (desc != null) System.out.printf("     Descrição: %s%n", desc);
            if (source != null) System.out.printf("     Fonte: %s%n", source);
            if (impedida != null) System.out.printf("     Explosão impedida? %s%n", impedida);

            Set<OWLNamedIndividual> passengers = getPassengersOf(ferry);
            if (!passengers.isEmpty()) {
                System.out.print("     Passageiros: ");
                for (OWLNamedIndividual p : passengers) {
                    System.out.print("[" + getName(p) + "] ");
                }
                System.out.println();
            }

            System.out.println("  " + "-".repeat(80));
        }

        printFooter();
    }

    private void displayQC2() {
        printHeader("QC2 - Quais passageiros estão em cada embarcação?");

        Set<OWLNamedIndividual> ferries = getFerries();

        System.out.println("\n  👥 Passageiros por Embarcação:\n");
        System.out.println("  " + "-".repeat(80));

        for (OWLNamedIndividual ferry : ferries) {
            System.out.printf("%n  🚢 %s:%n", getName(ferry));

            Set<OWLNamedIndividual> passengers = getPassengersOf(ferry);
            if (passengers.isEmpty()) {
                System.out.println("     (nenhum passageiro registrado)");
            } else {
                int count = 0;
                for (OWLNamedIndividual p : passengers) {
                    count++;
                    String nome = getName(p);
                    String desc = getDataValue(p, dphHasDescription);
                    String tipo = p.getIRI().getShortForm().replaceAll("\\d+$", "");
                    System.out.printf("     %d. %s [Tipo: %s]%n", count, nome, tipo);
                    if (desc != null) System.out.printf("        %s%n", desc);
                }
            }
            System.out.println("  " + "-".repeat(80));
        }

        printFooter();
    }

    private void displayQC3() {
        printHeader("QC3 - Quem detém o detonador de cada embarcação?");

        Set<OWLNamedIndividual> ferries = getFerries();

        System.out.println("\n  🎛 Detentores dos Detonadores:\n");
        System.out.println("  " + "-".repeat(80));

        for (OWLNamedIndividual ferry : ferries) {
            String nome = getName(ferry);
            System.out.printf("%n  🚢 %s:%n", nome);

            Set<OWLNamedIndividual> detonators = getRelated(ferry, propTemDetonador);
            for (OWLNamedIndividual det : detonators) {
                System.out.printf("     Detonador: %s%n", getName(det));

                // Quem controla este detonador (relação inversa)
                Set<OWLNamedIndividual> controllers = getRelatedInverse(det, propAciona);
                if (!controllers.isEmpty()) {
                    System.out.print("     Detentor: ");
                    for (OWLNamedIndividual c : controllers) {
                        System.out.print("[" + getName(c) + "] ");
                    }
                    System.out.println();
                }

                // O que este detonador controla
                Set<OWLNamedIndividual> targets = getRelated(det, propControlaEmbarcacao);
                if (!targets.isEmpty()) {
                    System.out.print("     Controla explosão de: ");
                    for (OWLNamedIndividual t : targets) {
                        System.out.print("[" + getName(t) + "] ");
                    }
                    System.out.println();
                }

                String acionado = getDataValue(det, dphDetonadorAcionado);
                if (acionado != null) {
                    System.out.printf("     Foi acionado? %s%n", acionado);
                }
            }

            if (detonators.isEmpty()) {
                System.out.println("     (nenhum detonador registrado)");
            }
            System.out.println("  " + "-".repeat(80));
        }

        printFooter();
    }

    private void displayQC4() {
        printHeader("QC4 - Qual foi o resultado do teste?");

        Set<OWLNamedIndividual> detonators = getDetonators();
        Set<OWLNamedIndividual> ferries = getFerries();
        Set<OWLNamedIndividual> bombs = getBombs();

        System.out.println("\n  🎯 Resultado do Teste Psicológico:\n");
        System.out.println("  " + "-".repeat(80));

        System.out.println("\n  [Detonadores]");
        for (OWLNamedIndividual det : detonators) {
            String nome = getName(det);
            String acionado = getDataValue(det, dphDetonadorAcionado);
            System.out.printf("     %s → Acionado? %s%n", nome, acionado != null ? acionado : "N/A");
        }

        System.out.println("\n  [Bombas]");
        for (OWLNamedIndividual bomba : bombs) {
            String nome = getName(bomba);
            String impedida = getDataValue(bomba, dphFoiImpedidaExplosao);
            System.out.printf("     %s → Explosão impedida? %s%n", nome, impedida != null ? impedida : "N/A");
        }

        System.out.println("\n  [Embarcações]");
        for (OWLNamedIndividual ferry : ferries) {
            String nome = getName(ferry);
            String impedida = getDataValue(ferry, dphFoiImpedidaExplosao);
            System.out.printf("     %s → Salva? %s%n", nome, impedida != null ? impedida : "N/A");
        }

        System.out.println("\n  📌 Interpretação:");
        System.out.println("     Nenhum detonador foi acionado.");
        System.out.println("     Batman impediu a explosão final.");
        System.out.println("     Ambas as embarcações foram salvas.");

        System.out.println("  " + "-".repeat(80));
        printFooter();
    }

    private void displayQC5() {
        printHeader("QC5 - Quais passageiros sobreviveram?");

        Set<OWLNamedIndividual> passengers = getPassengers();

        System.out.println("\n  ✅ Sobreviventes:\n");
        System.out.println("  " + "-".repeat(80));

        int count = 0;
        for (OWLNamedIndividual p : passengers) {
            // Verifica se a embarcação do passageiro foi salva
            boolean survived = false;
            Set<OWLNamedIndividual> ferries = getFerryOf(p);
            for (OWLNamedIndividual ferry : ferries) {
                String impedida = getDataValue(ferry, dphFoiImpedidaExplosao);
                if ("true".equalsIgnoreCase(impedida)) {
                    survived = true;
                    break;
                }
            }

            // Também verifica relação direta sobreviveu
            Set<OWLNamedIndividual> sobrev = getRelated(p, propSobreviveu);
            if (!sobrev.isEmpty()) survived = true;

            if (survived) {
                count++;
                String nome = getName(p);
                String desc = getDataValue(p, dphHasDescription);
                System.out.printf("  %d. %s%n", count, nome);
                if (desc != null) System.out.printf("     %s%n", desc);
            }
        }

        if (count == 0) {
            System.out.println("  (nenhum sobrevivente registrado)");
        } else {
            System.out.println("\n  Total de sobreviventes: " + count);
        }

        System.out.println("  " + "-".repeat(80));
        printFooter();
    }

    private void displayQC6() {
        printHeader("QC6 - Quais passageiros morreram?");

        Set<OWLNamedIndividual> passengers = getPassengers();

        System.out.println("\n  💀 Passageiros mortos:\n");
        System.out.println("  " + "-".repeat(80));

        int count = 0;
        for (OWLNamedIndividual p : passengers) {
            // Verifica se a embarcação do passageiro explodiu
            boolean died = false;
            Set<OWLNamedIndividual> ferries = getFerryOf(p);
            for (OWLNamedIndividual ferry : ferries) {
                String impedida = getDataValue(ferry, dphFoiImpedidaExplosao);
                if ("false".equalsIgnoreCase(impedida)) {
                    died = true;
                    break;
                }
            }

            // Também verifica relação direta morreu
            Set<OWLNamedIndividual> mortos = getRelated(p, propMorreu);
            if (!mortos.isEmpty()) died = true;

            if (died) {
                count++;
                String nome = getName(p);
                String desc = getDataValue(p, dphHasDescription);
                System.out.printf("  %d. %s%n", count, nome);
                if (desc != null) System.out.printf("     %s%n", desc);
            }
        }

        if (count == 0) {
            System.out.println("  (nenhum passageiro morreu — Batman impediu a explosão)");
            System.out.println("\n  📌 No cenário canônico do filme, todos os 6 passageiros sobreviveram.");
        } else {
            System.out.println("\n  Total de mortos: " + count);
        }

        System.out.println("  " + "-".repeat(80));
        printFooter();
    }

    private void displayQC7() {
        printHeader("QC7 - A hipótese do Coringa foi confirmada?");

        System.out.println("\n  🃏 Análise da Hipótese do Coringa:\n");
        System.out.println("  " + "-".repeat(80));

        // Busca hipótese
        Set<OWLNamedIndividual> hypotheses = getIndividualsByPrefix("Hipotese_");
        for (OWLNamedIndividual hyp : hypotheses) {
            String nome = getName(hyp);
            String desc = getDataValue(hyp, dphHasDescription);
            String confirmada = getDataValue(hyp, dphHipoteseConfirmada);

            System.out.printf("%n  Hipótese: %s%n", nome);
            if (desc != null) System.out.printf("     Descrição: %s%n", desc);
            if (confirmada != null) System.out.printf("     Confirmada? %s%n", confirmada);
        }

        // Busca teste
        Set<OWLNamedIndividual> testes = getIndividualsByPrefix("Teste_");
        for (OWLNamedIndividual teste : testes) {
            String hipoteseConf = getDataValue(teste, dphHipoteseConfirmada);
            String score = getDataValue(teste, dphHasScoreMoral);

            System.out.printf("%n  Teste: %s%n", getName(teste));
            if (hipoteseConf != null) System.out.printf("     Hipótese confirmada? %s%n", hipoteseConf);
            if (score != null) System.out.printf("     Score moral: %s%n", score);
        }

        System.out.println("\n  📌 Interpretação:");
        System.out.println("     A hipótese do Coringa NÃO foi confirmada.");
        System.out.println("     Nenhum detonador foi acionado em nenhuma embarcação.");
        System.out.println("     A cooperação e a empatia prevaleceram sobre o instinto");
        System.out.println("     de autopreservação, refutando a visão cínica do Coringa");
        System.out.println("     sobre a natureza humana.");

        System.out.println("  " + "-".repeat(80));
        printFooter();
    }

    private void displayStatistics() {
        printHeader("📊 ESTATÍSTICAS DA JOKERTEST-ONTOLOGY");

        int totalFerries = getFerries().size();
        int totalPassengers = getPassengers().size();
        int totalDetonators = getDetonators().size();
        int totalBombs = getBombs().size();
        int totalObservers = getObservers().size();

        System.out.println("  +-------------------------------------------------------+");
        System.out.printf("  |  Axiomas:                %-40d |%n", ontology.getAxiomCount());
        System.out.printf("  |  Classes:                %-40d |%n", ontology.getClassesInSignature().size());
        System.out.printf("  |  Indivíduos:             %-40d |%n", ontology.getIndividualsInSignature().size());
        System.out.printf("  |  Propriedades de Objeto: %-40d |%n", ontology.getObjectPropertiesInSignature().size());
        System.out.printf("  |  Propriedades de Dados:  %-40d |%n", ontology.getDataPropertiesInSignature().size());
        System.out.println("  +-------------------------------------------------------+");

        System.out.println("\n  📋 Indivíduos por Tipo:");
        System.out.printf("     - Embarcações:       %d%n", totalFerries);
        System.out.printf("     - Passageiros:       %d%n", totalPassengers);
        System.out.printf("     - Detonadores:       %d%n", totalDetonators);
        System.out.printf("     - Bombas:            %d%n", totalBombs);
        System.out.printf("     - Observadores:      %d%n", totalObservers);

        int totalTemOcupacao = 0, totalTemDetonador = 0, totalControla = 0;
        int totalEstaEm = 0, totalAciona = 0, totalObserva = 0;
        int totalTemPrazo = 0, totalTestaHipotese = 0, totalSobreviveu = 0;
        int totalMorreu = 0, totalImpede = 0;

        for (OWLNamedIndividual ind : ontology.getIndividualsInSignature()) {
            totalTemOcupacao += getRelated(ind, propTemOcupacao).size();
            totalTemDetonador += getRelated(ind, propTemDetonador).size();
            totalControla += getRelated(ind, propControlaEmbarcacao).size();
            totalEstaEm += getRelated(ind, propEstaEm).size();
            totalAciona += getRelated(ind, propAciona).size();
            totalObserva += getRelated(ind, propObserva).size();
            totalTemPrazo += getRelated(ind, propTemPrazo).size();
            totalTestaHipotese += getRelated(ind, propTestaHipotese).size();
            totalSobreviveu += getRelated(ind, propSobreviveu).size();
            totalMorreu += getRelated(ind, propMorreu).size();
            totalImpede += getRelated(ind, propImpedeExplosao).size();
        }

        System.out.println("\n  🔗 Relacionamentos:");
        System.out.printf("     - temOcupacao:            %d%n", totalTemOcupacao);
        System.out.printf("     - temDetonador:           %d%n", totalTemDetonador);
        System.out.printf("     - controlaEmbarcacao:     %d%n", totalControla);
        System.out.printf("     - estaEm:                 %d%n", totalEstaEm);
        System.out.printf("     - aciona:                 %d%n", totalAciona);
        System.out.printf("     - observa:                %d%n", totalObserva);
        System.out.printf("     - temPrazo:               %d%n", totalTemPrazo);
        System.out.printf("     - testaHipotese:          %d%n", totalTestaHipotese);
        System.out.printf("     - sobreviveu:             %d%n", totalSobreviveu);
        System.out.printf("     - morreu:                 %d%n", totalMorreu);
        System.out.printf("     - impedeExplosao:         %d%n", totalImpede);

        System.out.println("\n  🎬 Referência principal:");
        System.out.println("     Nolan, C. (2008). The Dark Knight. Warner Bros. Pictures.");
        System.out.println("     Rapoport, A., & Chammah, A. M. (1965). Prisoner's Dilemma:");
        System.out.println("     A Study in Conflict and Cooperation. University of Michigan Press.");
        System.out.println("     Darley, J. M., & Latané, B. (1968). Bystander Intervention in");
        System.out.println("     Emergencies: Diffusion of Responsibility. JPSP, 8(4), 377-383.");
        printFooter();
    }

    // ============================================================
    // GERAR PDF
    // ============================================================
    private void generatePDF() {
        printHeader("📄 GERANDO PDF DA ONTOLOGIA");
        System.out.println("\n  ⏳ Gerando PDF com todas as questões de competência...\n");

        try {
            if (this.ontology == null) {
                System.out.println("  ❌ Ontologia não carregada. Não é possível gerar o PDF.");
                return;
            }

            JokerTestPDFGenerator pdfGenerator = new JokerTestPDFGenerator(this.ontology);
            pdfGenerator.generatePDF(PDF_OUTPUT_PATH);

            System.out.println("\n  ✅ PDF gerado com sucesso!");
            System.out.println("  📁 " + PDF_OUTPUT_PATH);
            System.out.println("\n  📊 Estatísticas do PDF:");
            System.out.println("     - 7 Questões de Competência");
            System.out.println("     - " + getFerries().size() + " Embarcações");
            System.out.println("     - " + getPassengers().size() + " Passageiros");
            System.out.println("     - " + getDetonators().size() + " Detonadores");
            System.out.println("     - Baseado em The Dark Knight (Nolan, 2008)");

        } catch (Exception e) {
            System.err.println("\n  ❌ Erro ao gerar PDF: " + e.getMessage());
            e.printStackTrace();
        }
        printFooter();
    }

    // ============================================================
    // MENU PRINCIPAL
    // ============================================================
    private void showMenu() {
        int option;
        do {
            clearScreen();
            printHeader("🃏 JokerTest-Ontology - Sistema de Consultas");
            System.out.println(" Baseado em: The Dark Knight (Nolan, 2008)");
            System.out.println(" Arquivo: " + ONTOLOGY_PATH);
            System.out.println(SEPARATOR);
            System.out.println("  +-----------------------------------------------------------------------+");
            System.out.println("  |  1  QC1 - Quais embarcações participam do teste?                     |");
            System.out.println("  |  2  QC2 - Quais passageiros estão em cada embarcação?                |");
            System.out.println("  |  3  QC3 - Quem detém o detonador de cada embarcação?                 |");
            System.out.println("  |  4  QC4 - Qual foi o resultado do teste?                             |");
            System.out.println("  |  5  QC5 - Quais passageiros sobreviveram?                            |");
            System.out.println("  |  6  QC6 - Quais passageiros morreram?                                |");
            System.out.println("  |  7  QC7 - A hipótese do Coringa foi confirmada?                      |");
            System.out.println("  |  8  Estatísticas da ontologia                                        |");
            System.out.println("  |  9  📄 GERAR PDF com todas as questões                               |");
            System.out.println("  |  0  Sair                                                              |");
            System.out.println("  +-----------------------------------------------------------------------+");
            System.out.print("\n  Escolha uma opção: ");

            try {
                option = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                option = -1;
            }

            System.out.println();

            switch (option) {
                case 1: displayQC1(); waitForEnter(); break;
                case 2: displayQC2(); waitForEnter(); break;
                case 3: displayQC3(); waitForEnter(); break;
                case 4: displayQC4(); waitForEnter(); break;
                case 5: displayQC5(); waitForEnter(); break;
                case 6: displayQC6(); waitForEnter(); break;
                case 7: displayQC7(); waitForEnter(); break;
                case 8: displayStatistics(); waitForEnter(); break;
                case 9: generatePDF(); waitForEnter(); break;
                case 0:
                    System.out.println(ANSI_GREEN + "Obrigado por usar a JokerTest-Ontology!" + ANSI_RESET);
                    break;
                default:
                    System.out.println(ANSI_YELLOW + "Opção inválida! Digite um número entre 0 e 9." + ANSI_RESET);
                    waitForEnter();
                    break;
            }
        } while (option != 0);
        scanner.close();
    }

    private void printHeader(String title) {
        System.out.println(SEPARATOR);
        System.out.println(ANSI_CYAN + ANSI_BOLD + title + ANSI_RESET);
        System.out.println(SEPARATOR);
    }

    private void printFooter() {
        System.out.println(SEPARATOR);
    }

    private void waitForEnter() {
        System.out.print(ANSI_YELLOW + "\nPressione ENTER para voltar ao menu..." + ANSI_RESET);
        scanner.nextLine();
        System.out.println();
    }

    private void clearScreen() {
        try {
            if (System.getProperty("os.name").contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                System.out.print("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
            for (int i = 0; i < 50; i++) System.out.println();
        }
    }

    public static void main(String[] args) {
        new JokerTestConsultas();
    }
}